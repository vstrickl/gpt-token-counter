 left hand of my thumbs down. Right. Like, you know, when you're describing a position, where is my body in proportion to their body and where am I taking them and how she improved me so much just by showing up.

00:52:40:28 - 00:53:12:13

And I remember I would be at home just like I would run through a position. How do you teach an armbar from the closed guard to a person who can't see? I do that like I had to do that. And she became really good really quickly. And so I remember one day even as as small as she was physically, one day, a girl from a very reputable school came in and she was like, Hey, I see you guys got jiu jitsu over here.

00:53:12:13 - 00:53:31:19

I've been meaning to come, but you know, school's crazy. Can I just drop in and take the class? And I was like, Sure. She was like, okay. I was like, How long you been training? She was like, a year, year and a half. I was like, All right, cool. I was like, You want to roll with her? And she was like, Yeah, yo could not pass this girl's closed guard at all.

00:53:31:22 - 00:53:50:21

You could see was trippin, you know what I'm saying? She was trippin. And you know, the girl didn't finish her from the guard, but the girl could not pass. She kept her posture broke and she kept attacking every time she would go for an armbar whatever to girl was sit up. She'd go back, you know, bring her down.

00:53:50:27 - 00:54:14:15

You know what I'm saying? She was working the sweep attempts and it was like, yo, like I started to almost cry. And then I caught myself and I said, You're only about to cry because she can't see. And by feeling that way, you're not honoring the technique that she's displaying on her own. Let her be a great champion.

00:54:14:15 - 00:54:27:24

Like, don't add anything to it. You know what I'm saying? And when that round was over, I said, How do you feel? She was out of breath. She was like, I'm okay. And I was like, All right, I'm really proud of you. You know what I'm saying? And like, this is like the beauty of of, of this path.

00:54:27:24 - 00:54:49:13

This is this is how, you know, people always think about how their teachers, like, make them better. But but I'm always impressed about how my students make me better. And so every time anybody who who's ever studied under me, they know how I end. Every class I shake their hand, I give them a fist pump and I say, thank you for improving me.

00:54:49:15 - 00:55:12:04

Thank you for improving me. And that's because you, girl. Cano said that that is the purpose of the vow. You thank your opponent for improving you because you can't armbar and throw yourself. You can't choke yourself, right? You only respond to the level of pressure put upon you that takes you up to this level of greatness. So you always thank your opponent for approving you.

00:55:12:10 - 00:55:42:03

And so I always do that. White belt to black belt. First day, last 11 minutes. I'm always going to say thank you for improving me, because that's what you do, right? Like one of my homies, Adam, he said, like, you know how like in traditional martial arts people use this, this, this like way of like bowing, right? So he saying that the thumb is bent and that the thumb symbolizes the master bowing to his students.

00:55:42:14 - 00:56:03:00

word. And he was like yeah because Risa from Wu-Tang he always does this. He was like, Yeah, it's about the Sensei, the instructor bowing before his students in gratitude, right? And the right fist being covered by the hand of peace, right? Like you're choosing peace. And I was like, What? And so I always think my, my, my, my students for improving me, my my training partners for improving me.

00:56:03:08 - 00:56:33:25

And this is what I think jiu jitsu is supposed to do. It's supposed to leave us improved, right? And if we don't allow ourselves to see our experience on the mat as more than a win loss record, like I got Tap or I tapped everybody or, you know, somewhat like none of that is relevant. You know, you improve little by little every class where you get smashed or not, and nobody will ever remember your win loss record, but they will remember your character.

00:56:33:27 - 00:56:58:02

Yeah. Wow. Yeah, That's powerful. That's awesome. Yeah, I, I really feel that story. I was going to. I didn't want to stop you midway, but I was just going to say, Isn't it wonderful to, like, feel that I feel that part where you're the teacher, but your students are teaching you, they're there helping improve you as a martial artist.

00:56:58:02 - 00:57:22:15

And as I'm not going to just say as a person, but narrow it more specifically as a communicator, right. And how you relate and have relationships with other people. So I am not trying to namedrop here, but I used to train with Hyder a amil. He would teach me for the longest time and I would go to El Nino.

00:57:22:17 - 00:57:48:10

You know, he he just recently got his contract with the UFC, you know, when is this match for that? Yeah, he killed it. The record for a UFC contenders for the Most Takedowns defended it was like eight defended 18 takedowns. Anyways, I'm off on it at my tangent like our schedules don't match up any more where I can train with him right?

00:57:48:12 - 00:58:10:09

But I've like I've improved so much in my confidence, on my feet and my striking. It's just like a whole new ballgame to me that one of my clients who I teach well, I train her out of a gym. I'm not going to say the name because, you know, it's a commercial jab and you know, they don't want outside trainers coming in and training them.

00:58:10:09 - 00:58:52:15

So I, I train. Exactly. So I train her there and she wanted to do boxing as our cardio and mind you, is the same this week. So I you know, me and Hightower couldn't find her schedule matching up. So I decided, you know what, I'm just going to continue my training. From what I've learned from him, teaching you what I know, you know, and I notice myself, like, as I have to recall, how he would teach me how to throw my jab right, how he would teach me how to throw my cross, how he would teach me, throw my hook at the record, how he's like, taught me all these different combinations and why.

00:58:52:22 - 00:59:11:05

So it's like I'm I'm, I'm switching our roles. I switching our perspective on what our on my learning process essentially by teaching through teaching her.

00:59:11:05 - 00:59:18:04

It's powerful, man. It's powerful. I mean, I can't tell you how many times when talking to my students.

00:59:18:04 - 00:59:26:03

It's really gumbi from heroes martial arts, right? It's really Gumby talking through me to them.

00:59:26:10 - 00:59:46:16

It's not really me, you know, It's. It's the echo of Gumby. It's the echo of how Gracie is the echo of Charles. Gracie, Right. And even even, like, some of my best friends, like Danny Procopio, right? It's the echo of Danny, right? Like things that they taught me. Things that they told me, things that I saw. You know what I'm saying?

00:59:46:16 - 01:00:05:18

Things that I. That I saw from BJ Penn, Right? Things that I saw from Dave Cambria back when I was a white belt. You know what I'm saying? And like that stuff still it still sticks with me. And so it's like a lot of times when I'm talking, they're hearing it from me. But but these are the echoes of of my instructors and my training partner.

01:00:05:18 - 01:00:28:03

So yeah, I told him, Yeah, yeah. Thank you. Yeah. But I think you put you're a different style, you're a different flavor and how you say it or how you communicate it to them, you know, in a different way. You know, there's definitely for sure real statements that Darren has said to me that I'm sure you got from House.

01:00:28:06 - 01:01:00:26

You know, that's like I'm just saying that verbatim. Yeah. Because I understand, you know, in that moment that's what I needed to hear. And in this moment, this is what they need to hear. Yeah. You know, but for the most part, I would say that you know how I communicate the lessons learned from all the different instructors that I've had and training partners that I've had is through my own personal communication style and how I relate to things in the world, too.

01:01:01:03 - 01:01:28:18

So, you know, there's still some flavor of. Yeah, yes, I'm saying it's going to have your seasoning on it for sure, you know, And that's how it should be, right? That's how it should be. You know, there were there these really two amazing twin boys at Oral who they're young teens, I think, you know, like, I'm going to try to put no pressure on them, but I think they can be some future Rotolo type dudes, you know what I'm saying?

01:01:28:19 - 01:01:51:22

These two brothers and they're preteens right now. And so one day one of the boys is trying to trying to take me out. And then after the match, he came up to me and he said one day, you know, I'm going to tap you out. And I said, I said, you know what? You're right, and I'm going to teach you how to do it.

01:01:51:25 - 01:02:10:10

And his face just like, drop. But what that was like, I was like, okay, I've lost my job, bro. That's my job. I said, That was going to be ten, ten, ten more years. You know what I'm saying? If you got that kind of time. But I'm here for it, you know what I'm saying? And I'll show you everything I can help you learn.

01:02:10:13 - 01:02:39:19

And so, like, you, they they they work so hard. If I tell him anything, like drink more water, they'll be like, You know what I mean? If I say move like this, like. And so that's a huge responsibility, right? That's a huge responsibility. And so like the integrity that you have to maintain within yourself and the consistency that you have to maintain inside yourself sometimes, you know, I'm 53, I'm old man.

01:02:39:19 - 01:02:58:18

I don't want to be doing air squats at 930, don't want to be doing just push ups. I don't want to do no yoga, but this lower back will lock up if I don't do that yoga and this knee might quit on you, boy, you know, I hit them air squats, right? Or we don't take that leg. So I've got to do these things right.

01:02:58:24 - 01:03:30:03

I've got to watch the footage. I've got to watch the tapes right. Because I was thinking about this when I was coming home the other day. I was like, obviously I'm 53. At some point I'm going to kick the bucket. But like in some ways, the students that I've had to share information with here in the UK and back in the Bay, you know, ten, 15, 20 years from now, they'll be my echo will be coming out of their mouth when they're teaching a technique to someone.

01:03:30:05 - 01:03:53:24

And I was actually thinking about how beautiful it's going to be to not be here, but still be teaching jiu jitsu through young men like them and others. Yeah. Yes, absolutely. I'm looking up this quote right now. It was what am I, students, fathers. He sent me this. He he sent me some new ones, too. Okay, hold on now.

01:03:54:00 - 01:04:14:11

now. Okay. This one, what he sent me was pretty funny and poignant to what you were talking about when comes to was it? here it is. This is it. When it comes to your students saying that they're going to tap you out one day. And he said to be I want to be very clear about this.

01:04:14:13 - 01:04:44:26

I'm not working out to have a healthier lifestyle. I'm working out to dominate my children in any athletic and never as possible for as long as I want them to be terrified at 28, terrified of losing to me in a footrace like that. I love your, you know, look, you like one of my favorite like student parents. You know, we're we're always chit chat.

01:04:44:27 - 01:05:09:22

You know, we're pretty tight over here at physical, but yeah, yeah, it's a good squat over there. Beautiful squat. Yeah, absolutely. Absolutely. So we you know, I got you on here talking about resilient men. We kind of diverge. You did talk, but you know, you know how the podcast podcast game is. Know how it works. Sometimes we take gadgets, we're going to get back on track.

01:05:09:27 - 01:05:41:20

Have you ever had anybody like, have any resistance or criticisms about stoicism or the projects that you have? yeah, you have to tackle those. And so there's a couple of dude things, right? Like the first is just people not knowing what Stoicism is and really not feeling it because it's an old white thing at a time when like intercultural shifts are happening and are important.

01:05:41:22 - 01:06:03:21

So people are like, Yo bro, why are you talking about all these all white dudes all the time? Like, how come you're talking about committing masters of ancient Egypt? You ain't breaking down, you know, the Creoles of West Africa. Now, the truth is, if anybody really knows an OG they know I gave those lectures back in 1992. And I