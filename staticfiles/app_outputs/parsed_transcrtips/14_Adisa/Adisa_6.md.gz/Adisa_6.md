'm not kidding.

01:06:03:23 - 01:06:22:27

I'm not kidding. You know, there's a book called Stolen Legacy. Anybody is free to go pick it up. It talks about the African origins of a lot of what is now Greek philosophy. Okay. And so people would be like, how come you're not talking about that? And it's really like because you didn't know me 20 years ago when I was doing it doesn't mean I didn't do it.

01:06:23:03 - 01:06:55:05

And because I don't talk about it all the time now doesn't mean I don't know it. I knew it before you knew it, probably. And I've lectured about it at a collegiate level before you were probably even in college. So that's not really the point. The thing here is if you're dealing with stoic philosophy in a time where, you know, people are struggling against white supremacy as a system, and I'm not talking about merely a police officer killing an unarmed black woman or you know what I mean?

01:06:55:07 - 01:07:17:20

You know, a bunch of officers are piling a guy in, he dies or whatever, Right? Like I'm talking about the entire system that even makes those cops see that black man as less than human whether he's committed a crime or not. The fact that they see him as less than human, the fact that they see him as a super athlete, what kind and rebel that they can't control.

01:07:17:20 - 01:07:52:02

So they got to shoot him just when he, like, reaches to undo his seatbelt. Right. Like these are the kinds of things that the system of white supremacy combats in any righteous attempt to get justice against white supremacy. I cannot have a problem with that. However, we have to be careful about doing to white society what white society has done to us, which is to to negate and deny.

01:07:52:05 - 01:08:16:02

Right. No matter what you want to say about the African origins of of of of Greek philosophy, etc., Not here to debate it, because I already know that discussions better than many of those that try to make them today like it doesn't stop what the Greeks were able to achieve. It doesn't like saying, well, you know, because hip hop comes from soul.

01:08:16:06 - 01:08:46:18

Everything rappers did is trash. What? So we're just going to deny Tupac because he sampled this dude who comes from soul. You can't do that, right? What the Stoics did what's is Seneca Epictetus. What Plato was Socrates right. What Aristotle wrote like the greatness of that is not to be denied just because white supremacy is a real thing now, right?

01:08:46:20 - 01:09:12:10

So it's like I as a black man who benefit from stoicism, I'm not going to say, well, all this Greek stuff came from Africa anyway, so whatever. No, bro, part of justice is giving credit where it's due. From the beginning period. So I don't have a problem acknowledging the African origins of, of, of philosophy in those regards and acknowledging the Stoics.

01:09:12:15 - 01:09:38:23

And I'm not going to use a time when the ideas and words of white men are kind of like out of style and not mention these guys. If they brought great truth, if they brought great justice, if they brought great wisdom, if they brought great compassion, why would I deny the value of what they bring right now? So sometimes I think in some ways people who know me, know my writing, know a lot of the things that they're like, I don't understand why he's talking about all this great stuff right now.

01:09:38:25 - 01:10:08:00

Well, it's the same reason I talked about anything, because it works. Writing about it. That means it works not for everybody, but for me and a lot of people. So I got a lot of pushback on that. I definitely I think some of the weirdest stuff that I've experienced is once I started this, this Brazilian men's group in the United Kingdom, the funniest thing that happened was, a lot of black guys from America were like, What are you doing?

01:10:08:00 - 01:10:32:00

You got this thing going on in the U.K., You're not doing it here. I was like, Cool. I started putting it together. I'm like, We got to launch it on this day. Go ahead and sign up. Crickets. Nobody signed up. Nobody signed up. So then I'm like, Yo, man, the same dudes that that deemed me looking for it were the same people that didn't show up.

01:10:33:05 - 01:10:50:28

That's right. You just have to recognize that this is where, like, I'm not even faulting them. I just think that that's how afraid of facing themselves and trying to heal so many people are. So I'm not even mad at them. One of the guys like, Yo, man, I thought you was doing the U.S. group. I said I was doing the US group and nobody signed up.

01:10:51:03 - 01:11:11:21

And he was like, Dang. I said I was going to sign up and I didn't. And I was like, It's cool. Just sign up. And then once we got ten, y'all will get a pop, you know what I mean? But the group I got, the UK is lit and so, you know, I'm still going to do one in the U.S. and it's okay that nobody signed up because I know the sign ups are coming.

01:11:11:21 - 01:11:26:28

I know that people are in pain and I know that I'm not going to stop being there for them. So it doesn't matter. And you know, the reason why I appreciate you and, you know, so any woman listening, if you know a man, even if he looks like he's cool, suggested to him, he may not even know he needs it.

01:11:27:03 - 01:11:47:05

Sometimes the strongest looking dudes are the ones that break the most suddenly and the most horrific, you know. So I appreciate for even let me talk about the RMG and I and I appreciate all the women who have suggested you should get into. I think half the dudes in the Resilient men's group in the UK were sent by wives, you know what I mean?

01:11:47:05 - 01:12:09:19

So, you know, I applaud the women who, applaud the outreach and and are part of the outreach, you know, to make to make it possible. I know, you know, just for me as a woman, I don't always find the. go ahead. Sorry. Hold on. I got it. I got it. I got a flood watch over it. I'm out.

01:12:09:21 - 01:12:40:16

The rest of the world is dying. yeah. my. So you saw the camera died there for a sec. It was okay. It still is. Things that you can't last now. I just kept talking. We'll figure it out. Well, luckily, this as this podcast also goes on Spotify, so there's probably a lot of people who just listen in any.

01:12:40:20 - 01:13:13:09

Anyway, I would back what I was. Yeah, we back. So what I, what I was trying to say is that, you know, sometimes I really try to be tactful with how I suggest these things to my friends because I also know that sometimes just the mere suggestion of things coming from my mouth set resistance, even if it was something that they would have wanted to do in the first place, you know?

01:13:13:11 - 01:13:35:13

Yeah, and that's the thing. That's the thing is this is hard, you know what I mean? It's not always it's not always easy, you know what I'm saying? But know, I'd rather have you mad with me because I suggested it from a place of love, then be mad at myself because I didn't. Then you end up harming yourself or somebody else.

01:13:35:13 - 01:13:59:02

You feel me? Yeah, Kind of like what I'm at these days. But it is hard and it is a it is a it's not an easy thing to open the door to, you know what I'm saying? Definitely. Yeah, yeah, yeah, man. It says, yeah. Well, I appreciate you out here changing. Hearts changing minds, changing lives, the work that you're doing.

01:13:59:04 - 01:14:27:17

Thank you. Yeah, I'm trying. It's important those to make my life easier, you know what I'm saying? Who make who make the conversations easier? Who lend me an ear? You know what I'm saying? It's. It's a big deal. It's a big deal. And I'm grateful. Do you have any success stories from people who've been in your group? Well, you know, the group is no, we've only been around for think like two or three months now.

01:14:27:19 - 01:15:00:02

We've only been around for like two or three months. But yes, I mean, like all of the guys in the group and it's such a such a wide group of people because we got guys as young as 18 and guys that are over 50. And it's really it's really now I find like even though like yes, I'm talking about stock philosophy and whatever, like the open conversations are the deepest ones.

01:15:00:09 - 01:15:23:11

What start talking about like, you know, I'll be like, Yo, so like, what is one aspect of your life that you know, you're letting yourself down on and why do you think that is? And then everybody kind of goes through where they're failing themselves and why they think that is. And then to watch these men support each other.

01:15:23:13 - 01:15:41:13

I mean, they're all essentially strangers, you know what I'm saying? We're all essentially strangers. And they'll be like, Hey, man, I understand what you're saying. But I think if you did this, you probably achieve it faster. Or, you know, don't be so hard on yourself because, you know, this is also possible. And it's just beautiful, like to see that stuff happen.

01:15:41:15 - 01:16:05:06

And I think that that, you know, I believe that every person, you know, has been through something that would have broken. You just don't know that story. You could have come from their childhood, could come from their teenage years. But it comes young adult could have come as a O.G. like you just don't know. You haven't had that story told to you yet.

01:16:05:08 - 01:16:28:00

And so this is one of the reasons why be chill with people because. Everybody is a survivor of something incredible. Everybody is survivor of something incredible. And when I see these guys going back forth, helping each other from the heart without judgment, it's it's just it's just magnificent. I never get tired of seeing that. You know what I mean?

01:16:28:00 - 01:16:57:04

I never get tired of seeing this. Beautiful. That's awesome. That's awesome. Any revelations for your journey doing this work, anything that you grew from just by putting this this group together, by listening their stories? Yeah. Yeah. I mean, I always knew like, I was like, okay, I got this stoic outline and know what I want to do, etc., etc. But.

01:16:57:07 - 01:17:36:05

Man, even as the guy who's the facilitator of the group, I lead by sharing my with my own vulnerability, right? With my own shortcomings, with my own pain points, with my own struggles. And I do that intentionally because, again, I'm not trying to be seen as like some type of guru who's got it all figured out. And sometimes they're they're they're their suggestions to me are groundbreaking.

01:17:36:07 - 01:18:09:01

They're Their suggestions to me are mind blowing. Their suggestions to me are supremely inspiring, you know? So, I mean, you know, it's just kind of a reflection of that whole thing. Well, let me find this quote real quick. You know, I just want to say, for the guys at home, I had this bag of plantain chips that I spilled all over the ground.

01:18:09:03 - 01:18:39:00

And my rabbit is currently acting as a vacuum cleaner for me, for my little combs that I couldn't pick up. She loves the plantation. I hope she doesn't die. Yes. What is this, Rabbits. Right now they're not. But I just. She's had them before. She intelligence and other things. But says just do this, this, this, this thing. And this was actually the first person that to teach me.

01:18:39:00 - 01:19:05:14

This was actually my fiancee and but it's true of all human beings. And this is the beauty you see in me is a reflection of you. That's Rumi. The beauty you see in me is a reflection of you. And so when I'm talking to these guys as the one that's supposed to be the facilitator, and they're reflecting all this beauty to me that I didn't expect, that I that I didn't even show up for.

01:19:05:16 - 01:19:35:03

I'm trying to show up as the helper, and then you get the help. That's just that's gold skull. Yeah. So what's next for the group? So our group meets Mondays 7 to 9 p.m.. That's I think 11 to 1 if you're on, if you're on Pacific Standard Time 1101 on Mondays. And so we are just going for it.

01:19:35:03 - 01:20:11:27

You know, we'll have our thing going on tomorrow. You know, we rotate between like deep stoic conversations and open conversations and this upcoming one is open. So I'm just looking forward to seeing what everybody's been up to. You know, it's a wide group of people, like some dudes are like attorneys for large acquisition and merger corporations and other guys are like sound bath crystal, like Masters and others are college students and others are business leaders and others are artists.

01:20:11:27 - 01:20:38:19

Like it is a and some are martial artists and it is just a ragtag group of dudes. But like, we just have the most amazing time, you know? So again, if you go to at Bishop Chronicles, you can learn how to sign up and be a part of it. And I'm working on setting up the American group like within the next few weeks, like by later than like mid-October, we should have the American RMG up and running.

01:20:38:21 - 01:21:09:04

And, you know, I'm grateful to any no one will be denied like, you know, just come through register. You know, you'll see quickly that it's a worthwhile