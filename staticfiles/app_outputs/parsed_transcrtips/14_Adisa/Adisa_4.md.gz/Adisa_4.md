 very powerful to see how being still in nature has moved so many societies. And then we get to this place where so high technology that we've forgotten our own origins, right. And forgotten own roots, it's powerful. Well, I'm going to try to not be so political, but it's going to be hard with my this next statement, which is it reminds me a lot of, you know, just African ancestry and how we were removed from that, from like those traditions and that history and those spiritual practices in a sense.

00:39:11:23 - 00:39:37:10

And and it's like, you know, I wouldn't say I'm doing a lot of research to get back to that point, but I love I do love technology for connecting us to those different cultures so that I can see and I can understand, this is what, you know, people from this area would do, like especially as a black woman, this is how we would actually take care of our hair.

00:39:37:13 - 00:40:05:28

This is how we would take care of our bodies. This is how we would eat. This is how we would connect with nature. And even though, you know, I'm still removed here in the United States, I'm using technology as a way to open myself up to different worlds. It's still it's humbling to know how removed we are from all that ancient history, that ancient knowledge that served us to be more grounded, as you said.

00:40:06:00 - 00:40:30:20

Yeah. No, no, no. It's it's a big deal, you know? And so this is where we bring it back to jiu jitsu, right? Because a lot of my health now actually comes from Gracie Jujitsu. Right? You know, I was lucky enough to meet and interview Ariel Gracie back when the UFC was brand new, back when Boyce was in there mopping and choking Fu's out.

00:40:30:22 - 00:40:53:25

And, you know, I remember Maureen telling me about the Gracie Diet. You know, I remember Marianne telling me about the importance of juicing and saying, you know, what is it, Guarana, that that other like Berry, You know what I'm saying? And so, like, I remember having Guarana for the first time and they were laughing at me because I hadn't eaten that day.

00:40:54:00 - 00:41:35:12

And then I was I was drinking. They were like, this was about to be off the off the Richter, you know. And I was but, you know, I juice now like everybody knows me for juicing my actual juice. Not juicing like, you know. Yeah, yeah. I'm not juice, you know, I just, I had in high school and still here, but, but I, you know, I juice a lot like almost every day, you know, I have natural juice and then I'm Bishop Chronicles.

00:41:35:12 - 00:41:54:18

I'm pretty sure it's still up. I got to interview Ralston Gracie, who basically became a fanatic about the doctor save diet, and he's blended it with the Gracie Diet to improve health and stuff like that. And so he and I, you know, that's my brother for real. Like we still talk about all of that stuff and more every day, right?

00:41:54:18 - 00:42:19:06

But this house, it is interesting because I've known I've I've met Halston when I was a white belt and he really randomly pops up like, I'll just see him like, real like, wow, Nice to see you. Real. It is kind of crazy. I got to look where you are. Yeah, you're right. Right. He's just doing amazing and he'll just pop up Jake the subject.

00:42:19:06 - 00:42:40:00

So. Yeah, true story. So I'm chilling, right? I'm like, Yo, man, I got to. I got to you know, I was. I was taking this this woman I'm still with on a on a great date. I got to figure some cool. So I'm like, I'm to take her to Muir Woods. We're going to walk. We're going to go for a walk in the woods, maybe go to your beach.

00:42:40:03 - 00:43:02:08

So we walk in. Muir were chillin when the cuts of Muir Woods. I don't even know where I was, You understand? I literally don't. We're walking around. It's a great day. you want to have a sit for a bit? Yeah So we're just sitting on this bench and we're chillin now. I had told Ross and I said, Hey man, you know, I won't be chilling with this lady.

00:43:02:08 - 00:43:20:15

And, you know, I was thinking maybe like, have you ever, like, cook dinner for somebody? But like, I was like, what if I broke you off? Right? Left you at the house? I'd go on the whole walk thing, and I come back and you, like, cook dinner. He was like, Yeah, we can figure that out. But our schedules are too crazy and we didn't figure it out.

00:43:20:21 - 00:43:47:08

So anyway, I'm sitting here chillin, we talking on a bench, and all of a sudden we see this dude in the distance and he's running with his shirt off at a really fast pace and he gets close. And I'm like, Ralston, He's like the super lady. it's like he looks at me. He's like, Is that. Is that.

00:43:47:08 - 00:44:11:12

What were you talking about? I was like, Yeah, that's her. It's like it was, yeah, you know, but we couldn't get figured out yet. It was hilarious. But Ralston is so wise. He's always studying and he's always, like, trying to study the body, food, the earth. And he's just. He's an impressive dude, man. He is an impressive dude.

00:44:11:12 - 00:44:30:24

Match That shot to that. Yeah, yeah, yeah, I always have. I don't. You know, we're not tight like you. Like I just see him. I'll just see him randomly. But I always have cool converse Asians with him. You know, any time I do talk to him and catch up and it's kind of like, you're still traded, you know?

00:44:30:27 - 00:44:56:01

Yeah. This is amazing, man. Yeah, yeah, yeah, yeah. That's cool. But yeah, this is how jujitsu can save your life, right? That there are limits to what you do you can and should do for you. Maybe mentally and emotionally. And you should always look for therapy, look for support groups and things like that. But what jujitsu does do to enrich your mind, to open your heart to your own potential, to to to test your body and help show you what you're capable of.

00:44:56:08 - 00:45:18:01

I don't think there's a better tool in the modern world than jujitsu for that. I just don't. And you know what? Look, this is no disrespect to anybody who likes hoops or soccer or Parcheesi or whatever they get into. I'm just saying I don't think that anything will help you grow as quickly into learning about who you are and what you're capable of as Brazilian jiu jitsu.

00:45:18:03 - 00:45:44:12

You know, I just don't. Yeah, I, I agree. And I think you know, we're both bias and I'll do that. Yeah you know I'll be open to bias but I it too because you know there's always this social component with a lot of group sports. You know you have a social component to basketball team football team, you know any anything where there's a team involved.

00:45:44:14 - 00:46:18:27

I just find that the the connection with martial arts specifically and jujitsu is different because it's deeper. It just comes from way. Yeah. You know, and the school that I'm on right now you know Gracie Eberhardt Roundhay Leeds is an unbelievable school because the guy who moved is, like I said, Mike Bates and T, you know, they're like, yo, like this is a community project first and a jujitsu school second, you know?

00:46:18:27 - 00:46:43:02

I mean, like jiu jitsu is secondary to building the community. So there's so many kids, so many families, so many moms, so many dads that come and train. And it's just fantastic. I stick to see how the community engages itself. I just you know, I haven't seen anything like that. And I'm from the Bay, where is probably one of the best places on earth to learn jiu jitsu ever.

00:46:43:07 - 00:47:05:14

OC is the San Francisco Bay Area. But the level of community that I see being intentionally and consistently cultivated by Mike Bates and TI and all the coaches over there at IRL, it's amazing that anybody would tell you that when they come to GBR, they're like, This place is different and they're right. And it's not that like, you know, it's a relatively new school, right?

00:47:05:14 - 00:47:26:29

So most of the students there are Blue Bulls. I think they only have like one purple belt. And then, you know, it's it's a few black belts, you know what I mean? Teaching, you know, and a lot of blue belt coaches teaching. But like, man, like what you get out of those classes in terms of community, I just I haven't experienced it anywhere else.

00:47:26:29 - 00:47:56:15

And that's why I love the school so much. Yeah, that's amazing. That's amazing. Yeah, It's a beautiful thing. Well, so what are you have any memorable stories from, you know, that commuting build community building experience or even just in your life any anything from your life in jujitsu? I know you have a lot on the podcast on Bishop Chronicle podcasts.

00:47:56:15 - 00:48:35:29

If people want to follow in one anything you want to share. Four for my podcast. Yeah, yeah, let me think. Let me think. Community building Community crazy. So this is going to sound maybe corny to some people, but I really love this experience. So there's there's a young boy at the school and he has two stuffed animals and he brings them to every class and we give each other fist bumps and stuff all the time.

00:48:36:01 - 00:48:58:15

But he always makes sure. He always asks if I can give his stuffed animals this once before and after class. And so one particular day he comes in and he is crying. I mean, this boy is shattered like he's in his gear and he's just like, and I'm like, What's wrong, bro? Because he doesn't even want to get on the mat, like, what's wrong?

00:48:58:15 - 00:49:23:18

And he's like, my mom left Jeffrey at home. I'm like, What? Jeffrey can't make it to class, and I don't want to be here without him. And I was like, okay. I was like, But check this out. I was like, I miss Jeffrey, too. But what if, like, you got to go back to Jeffrey and like, all he's going to want to know is how was class today?

00:49:23:25 - 00:49:37:04

You think he's going to be happy? You just tell him he's over here crying and not learning. He's going to want to see what you showed him. And if you stay over here crying all day, you're going to be like, I was crying all day. And Jeffrey is going to be like, Well, you didn't learn nothing, and that's going to be bad, man.

00:49:37:06 - 00:49:49:29

Why don't you just come on the mat and chill and do that? And he did. He got on. He had a great class and I was like, All right, I want you to tell Jeffrey I said hello. You know what I'm saying? And show him what you learned today. And he's like, okay. And he was like, super happy.

00:49:50:02 - 00:50:16:21

So then like, really that and Jeffrey is a SEAL and he had a snow seal, a small snow seal named Jeffrey Junior. And he was like, Look, now I got Jeffrey and Jeffrey Junior, I need you to give them fist bumps. So now I got to give him this. And once there, but like to see him be resilient at that age and choose to train, it was just really touching for me.

00:50:16:23 - 00:50:43:23

You know what I mean? And to me, I think there's nothing better than helping seeing jujitsu teach a person that they can do something that they didn't think they could do. You know, I had a student in San Francisco who a young woman who was who was visually impaired. She was, you know, just you know, she was blind, essentially.

00:50:43:23 - 00:51:08:21

Right. Like she uses a cane and all of that. And she I don't think she weighs £100. And she wanted to learn jujitsu. And so the school had asked me, you know, how do you feel about teaching like a blind woman? And I was like, This is my dream. Like, I was like, know, like, people don't know. I can't see, like, at all.

00:51:08:21 - 00:51:35:11

Like right now I can see your form and your color. I can make nothing out like I am is bad over here. So she comes to class and everybody at USF, like, really embraced her and said, you know, I remember being afraid to do the warmups with her because I was like, What if the warmups kill her? She's never done this.

00:51:35:13 - 00:51:51:11

You know what I mean? She may be like, What? I ain't got time for this ever. Yo, she never complained when we did that first warm up because I was watching her. Here come the push ups become the jujitsu push ups. You come, you know, say you come to Kimmy's. And I was waiting for her to be like, I'm out.

00:51:51:14 - 00:52:20:02

Nah, stay down. And when I would show a move, she improved me because I realized that there was a big gap between what you think you're doing and saying what you're actually doing. Yes. Yeah. There's a big gap between what you're doing and what you're saying you're doing. All right. So here I'm grabbing the wrist. Grabbing the wrist.

00:52:20:02 - 00:52:40:26

What does that mean, Grabbing the wrist with my left hand and the thumbs up, grabbing the wrist with the