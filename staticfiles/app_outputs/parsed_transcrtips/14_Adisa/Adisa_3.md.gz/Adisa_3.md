 the mother is ultimately based on the mental health of the mother.

00:24:06:26 - 00:24:29:07

And we're living in a world that's crazier by the minute. So, you know, we all need these resources, we all need therapy, we all need an outlet, we all need philosophies. For me, it's stoicism. For somebody else, it might be Buddhism for somebody else, it might. It might be meditation or whatever. But we need to be looking to find solutions to discover and cultivate our joy and our peace.

00:24:29:10 - 00:25:11:25

Deliberately inconsistent. Yeah. Amen to that. To man. That's deep. Yeah, it it it, it. I try to be really sensitive about, you know, that type of, you know, suicide and things of that nature, because I've gone through it myself, my own struggles. And I know like, people are ashamed to ask and reach out for help in those instances and they or they don't they're ashamed or they don't really know how to ask or who to ask.

00:25:11:28 - 00:25:27:24

So, no, you know, how do you even explain what you going through when you haven't really thought about it? How did I get here? How did I get to this pain? Why I don't want to harm myself? Why do I think my life don't matter? You know what I mean? Like, it's hard to even know that stuff. You know what I mean?

00:25:27:27 - 00:25:57:23

Yeah. So. No, I agree. I totally agree. Yeah. So. Yeah, I, I, yeah, I just yeah, it's a very as is the subject matter that I care about very deeply. And, and that's definitely, you know, I've had a a lot of different things that sparked this podcast, you know, my first podcast guest was my friend goalie and she's a therapist.

00:25:57:23 - 00:26:31:07

She's a she. Well, she, she doesn't have her license as a licensed psychologist yet, but she has her master's in psychology and she's practiced. She's just taken the test to get her her license here. And so she was my first podcast guest because last year when we reconnected, we had this deeply spiritual conversation about coaching and mental health and spirituality and just listening to her perspective on how she was speaking about it.

00:26:31:09 - 00:26:57:04

My whole physical body was vibrating, and I don't think I've ever had that experience with somebody where I'm talking to them and their words that they're saying moved me so much that I just feel like my whole entire aura and spirit changed to the point where I was vibrating. Yeah, exactly. And I was like, Go, got to have you on this podcast.

00:26:57:04 - 00:27:32:08

You know, we didn't get unfortunately, it was the first podcast, so we didn't get that deep. We were mostly just catching up, talking women and jujitsu and all those other things. So the guests are missing out, but we'll have goalie back on again. But yeah, the yeah, know, it's powerful, you know, and I mean the thing is too is man, I feel real bad right now because I'm blanking on a brother's name, but he's the guy that runs off clothing and he does all the cool stuff down at Sano Couch.

00:27:32:08 - 00:28:04:12

Sarah, You know, and I went down there one day because I was working on some stuff promoting one of the smokers that Dorian Cartwright over at Gracie Brands. You know, he always runs cool smokers. And somehow I went over there to promote the smokers and drop off some posters. And I didn't even realize that, you know, that dude, his background is actually mental health and is actually in helping incarcerated youth, boys and girls all over.

00:28:04:12 - 00:28:25:07

I think I'm probably messing up, but it was up in like, I think Oregon and I think Hawaii and some other spots. And one time we were talking and he was talking to me, I think about a woman who had passed away after taking her own life in jujitsu. And I was like, Why do you think that that happened?

00:28:25:13 - 00:28:45:10

Then he was like, Yeah, because jujitsu is not a replacement for therapy. And I was like, and it's deep because, you know, there's a lot of people who work out all the time and they'll be like, you know, the gym is my therapy, right? And there's people that'll be like, Yo, bro, if I'm not on the mat, I'm just not right to match my therapy, bro.

00:28:45:12 - 00:29:24:07

Like that makes sense to a degree, but real therapy is still cool, right? Like, don't, don't miss, don't, don't misconstrue the beauty of those experiences. In fact, my therapist said I think he used the term called cognitive bypassing, right. Where people use their faith so much that they're still not really dealing with themselves. Right. I will use stoic philosophy to, well, that looks like this and that looks like that, but you're still not really dealing with yourself and your issues and things like that.

00:29:24:09 - 00:29:51:22

So, you know, it's crucial that we do. It's crucial that we do. And so, you know, it's it's powerful, man. It's powerful. And we need to, you know, use jujitsu to enrich our hearts and our minds and our bodies. But but still take time to be deliberate about the emotional and psychological help that that we need. Yeah. Yeah, absolutely.

00:29:51:22 - 00:30:19:28

Absolutely. It becomes you know, I know for myself, when I first started doing jujitsu, I used jujitsu as my escape haven until I couldn't till I got to that point where I talked about, you know, what I talked about with my mental health issues. And it was to the point where it was like it was either I remember getting to that point and I was like, I either am going to live or I'm going to die.

00:30:20:01 - 00:30:40:18

I'm either going to choose to live or I'm going to choose to die here at this point right now. And failure or die to me was not an option because I still there was still hope for me. I still wanted to see more of my life happen. So in my head I was like, But, you know, failure here is not an option.

00:30:40:24 - 00:31:03:29

So how do I get myself out of this hole? And I didn't have the tools or the answers at the time. I was just scraping and holding on to any piece of knowledge that any person that I had in my life, You know, my mom during that time was a huge support. I don't know what I would do without her.

00:31:04:02 - 00:31:25:17

My coach, Darren at the time was a huge support. That's one of the reasons why I'm so tight with him, because it was like in the darkest moment of my life, you had my back and that's a big deal for me now. That's the same for me. Yeah. You meet Gumby, hit me up, and he heard me being fragile and he was like, Yeah, you need therapy.

00:31:25:17 - 00:31:41:20

Like, he was just like, off the top. He was like, I'm going to pay for the first session. Call this number, Get on it. You know what I mean? And I did it. Yeah, that was crucial. You know, one day I was like, on the real life, I was looking around the house for stuff to offer myself with.

00:31:41:22 - 00:31:59:21

And my dad just happened to call, and I wasn't even talking to him about anything crazy, But I think he could just hear the darkness. And he was like, What are you doing for dinner tonight? I was like, Nothing is all right. I'm gonna come over and get, you know, was like, okay, like he saved my life that day.

00:31:59:28 - 00:32:24:26

I tell him that, bro, you saved my life that day, because if you wouldn't invited me over for dinner, that would have been it. You know what I mean? Yeah. And I like it's hard for all of us. I think that, you know, there's a lot of reasons that we complain about the American school system, but one of the things that we know they don't do is they don't really address the emotional needs of the young people and teach them how to deal responsibly with what they feel.

00:32:24:28 - 00:32:56:05

And so I hope that in the future, you know, that changes. And I just hope to be a have a hand in that, you know, helping young people find value in themselves and worthy of contemplating and cultivating the best aspect of whoever they are, you know, before they fall for how many people do or don't like them. On Tik Talk or YouTube or IG, you know, that they can find and love themselves.

00:32:56:08 - 00:33:29:28

And, you know, unfortunately, you know, many adults, we just we still struggle with the same thing. You know. Yeah, yeah. Finding value in things outside of ourselves and external things. Right. How many likes do I have? How much success can I gain, How much how hard can I work to be valued? Well, those things, what I found to keep myself out of that hole is finding value in myself intrinsically, within the things that I that I am not by things that I do.

00:33:29:28 - 00:33:56:02

You know. And so that's shifting where I put my energy and where I put my value for myself really helped me release a lot of in my life, not just negative people, but negative thought patterns, led negative habits, negative behaviors, because I just yeah, at anything is like, who am I being in this moment? Not what can I do?

00:33:56:02 - 00:34:20:04

What can I do for this person? How can I be for this? If I'm if it's for somebody else, how can I be in this relationship? How could I be a better girlfriend? Not what can I do for you? Yeah. And, you know, I think a lot of it too, is like society works so hard to keep us distracted that it's very hard to figure out who we are when we're always in our phone.

00:34:20:04 - 00:34:40:21

You know, I struggle with phone addiction still, you know what I'm saying? But like, you know, when I was at the next 45, even though I had really happy to do the keynote talk, which was called Stoic Philosophy, Life and love, like looking at stoic philosophy through the lens of love, like what does it mean to be loving and to stoic?

00:34:40:21 - 00:35:08:13

And there's different kinds of stoic love, love just in the in that philosophy. But like, my my best time was actually paddleboarding on a lake by this whole thing of lily pads and lotuses. And I was just by myself. Yeah, we just would. And I was like, Yo like coasting by this whole, like 30 or 40 feet thick of lily pads and lotuses.

00:35:08:17 - 00:35:30:12

It was just perfect silence. All I could hear is like my paddle. Like, that was the best thing. That was the best thing. Even more than, like, how happy I was with my talk. That was the best thing for me, right? But we live in a world where being by ourself seems dumb, being by ourself seems you being too nerdy or you being too weird or whatever.

00:35:30:15 - 00:35:53:01

But really, like if you look at a lot of Buddhism and Confucianism specifically, right, they talk about how hard it is for people to be by themselves without music, people to be by themselves, without, you know, things to distract them. Right. And so, like, we have to learn to be at peace with who we are. And then everything starts to open up.

00:35:53:03 - 00:36:19:20

Yeah, I think being in nature is super helpful for that because in the home, it's not just easy for us to be distracted by all of the technology and the electronics, the TV, our phone, things that we have to do around the house to clean. But we're already so removed from nature being, especially if you live in an urban environment, right?

00:36:19:20 - 00:36:48:13

So soon as I set foot on the sand or put my feet in the grass, I get a pletely different energy shift and I don't need music at that point. My music is the way I leaves or it's be yo, you spit in bars right now because like, like before I, before I before I started coming back and forth out here a lot and trying to hang out here.

00:36:48:16 - 00:37:11:10

I used to, I used to jogging Linda Mah beach in Pacifica and I would get up outrun full span of the beach, down one side and back and then I would take my shoes off and I would walk with the waves just kind of going like, like ankle, ankle high, you know what I'm saying? And I never better than when I was doing that.

00:37:11:12 - 00:37:31:23

You know, I never felt better than when I was doing that. And there's this thing if you go on YouTube, I think it's called the Shuman residence Resonance, and it is the frequency of the earth. And so a lot of times what I'll do is I'll sit on the earth or stand barefoot on the earth. It's called grounding, right?

00:37:31:23 - 00:37:53:08

Because the energy from the earth, it goes through your body. I'm not talking like hippie stuff. I'm talking about life, actual, measurable science. It's called grounding. And it's good for your body to be on the earth so you can stand on grass or sand or whatever it's called grounding. Right? And I would listen to the Earth's frequency. It's called the Schumann Resonance.

00:37:53:11 - 00:38:22:01

And if you listen to that with headphones on and you just sit still, it's unbelievable. It's unbelievable. And it's incredibly good for your actual brain. Right? So, you know, the Stoics were about nature, the Buddhists were about nature. The Sufis were about nature. And you find, you know, even if you look at things, you know, ancient like Freemasonry, you find that a lot of the things that they were doing were connected to reflecting nature.

00:38:22:04 - 00:39:11:23

And at that time it was becoming modern society. And so it's