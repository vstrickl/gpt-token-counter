00:00:00:00 - 00:00:01:09

it in a lot of ways.

00:00:01:09 - 00:00:04:27

that was the beginning of me finding myself in jujitsu,

00:00:04:27 - 00:00:06:20

you've been a huge

00:00:06:20 - 00:00:10:18

black male leader for here in the Bay Area and just throughout the U.S.

00:00:10:18 - 00:00:11:15

with your

00:00:11:15 - 00:00:13:23

jujitsu chess program, you had,

00:00:13:23 - 00:00:14:24

you were

00:00:14:24 - 00:00:16:10

putting together different art

00:00:16:10 - 00:00:17:24

or museum exhibits,

00:00:17:24 - 00:00:19:25

just let people know our history.

00:00:19:25 - 00:00:22:22

we're actually bringing in a lot of guests here.

00:00:22:22 - 00:00:24:07

Bishop Chronicles podcast

00:00:24:07 - 00:00:26:23

they were enlightening. You always start off with your

00:00:26:23 - 00:00:29:24

your stoicism part of the day.

00:00:29:24 - 00:00:36:27

Yeah. That's kind of why when you and you have a group going on for it was the Resilient Men group.

00:00:36:27 - 00:00:38:11

And I kind of want to understand,

00:00:38:11 - 00:00:38:26

you know, what's

00:00:38:26 - 00:00:41:09

that's all about. Who are you looking to help

00:00:41:09 - 00:00:43:14

and how are you helping these these men?

00:00:46:12 - 00:00:49:25

And so I've been out here, I've been coming back and forth for, like, four years. You know what I'm saying?

00:00:50:21 - 00:01:17:28

And so I'm supposed to get my. My, my, my, my, our my work visa. Okay, so I apply these people want to hire me to work at this school. I'm like, cool. And then the UK embassy, this woman gave me really bad information and I went with it. Lisa just got denied. That's why I'm coming back.

00:01:18:01 - 00:01:43:02

So I got to get up out the country real quick and reapply. You feel what I'm saying? And so, like, I just got this fucking apartment with my homey, like I'm right around the corner from the school that I teach that shit is laid out here and now I got to fucking leave. And so it's like, it's really weird, Bill, but I've been, you know, I've been working with this stuff called Stoic Philosophy for the last few years.

00:01:43:04 - 00:01:57:08

And like, it's a big part of it is based on this thing called the dichotomy of control, which is just understanding things you can control and things you can't. And if you can't control it, you don't trip. So I was like, All right, you got to get out. I was like, By what date? They're like, This date I just went on to redo.

00:01:57:10 - 00:02:21:24

I got my ticket, I'm headed back and I'm not tripping because I really believe, like, my future is out here and shit. You know what I mean? Like, all these happen out here. We got a big competition coming up next weekend, you know? So what competition is that it's called? I think it's called the Empire Open. It's called the Empire Opened Jujitsu here is where jujitsu used to be in the bay, like 20 years ago.

00:02:21:27 - 00:02:39:01

So it's fun. It's a fun time. Like, schools are popping up, the school gets big, then it breaks off and that school gets big and it breaks off. And so it's like you're seeing like every you know what I mean? It's just it's great. It's well, I mean, the skill level seems to be there, too, because you got what?

00:02:39:01 - 00:03:07:09

Well, I'm going to say just a whole UK. I'm not going to say, Are you in England or what? Yeah, I'm in. I'm in Leeds, which is like about 3 hours north of, of London, you know what I mean? And so, I mean, this is where Roger Gracie lives, you know what I'm saying? He lives in London saying like and I think also that people think of England as like super, super white, which it always will be, but it's also way more integrated than people think.

00:03:07:11 - 00:03:28:24

So there's a lot of Irani, a lot of Dagestani, a lot of Japanese, you know what I'm saying? So there's a lot of judo out here. But I think people I mean, you know, Futaba. Futaba, the owner of the gym, she's from London. I mean, she she spent a lot of her life living on one. Exactly. And it's very it's much more multicultural than you would think.

00:03:28:27 - 00:03:46:04

And just like, I think one, you know, the reason why I think, you know, and my instructor, Gumbi from Heroes martial Arts, I he really pointed out that, you know, the reason the Bay is so dangerous is because so many different kinds of people are there. you do kung fu? Yeah. In Chinatown, you can see what's up.

00:03:46:09 - 00:04:07:13

you do judo. There's Willie Cahill, There's San Jose State. you do jujitsu. There's a whole bunch of Gracie's. And you know what I mean? And they're students. Students? You know what I'm saying? So, like. Like London and England in general is the same. You know what I mean? A lot of sick ass wrestlers from Turkey and stuff are out here, you know what I mean?

00:04:07:13 - 00:04:26:14

And it changes the way that jujitsu gets executed, you know? I mean, because the entry point becomes different, right? Like a Dagestan is going to grapple different than a judoka. You know what I mean? And if these things like making what the standup game of of the UK is, then it changes everything. So it's really powerful. Yeah, yeah, yeah, yeah.

00:04:26:15 - 00:04:50:13

That sounds cool. Yeah. I mean, Fiona, the frickin phenom right now is from the UK. From Wales? Yeah. Yeah. And plus they have the, the Polaris Pro, which is just an amazing series where they really try to like, highlight and showcase women but just like justifies themselves are very high, high energy. The crowds, they get it, you know what I mean?

00:04:50:13 - 00:05:19:13

Like it's. Yeah, it's really cool. Yeah man that's. I haven't been to England in so long. I did I, I went once with my mom in my twenties. I'm almost, you know, 40 now. We're not going to talk about that. I'm living life to forget at the age I live with my mum. Have a good time. So whatever you look like, you still in your.

00:05:19:16 - 00:05:35:05

You know what I'm saying? Would move in. You know what I'm saying? It's good. You know, I try. I do my best. I do my best. You know what? I forgot something too. I forgot something. I'll make this podcast announcement real quick. I'll be. Well, take us as long as it took us to get set up for this.

00:05:35:05 - 00:05:42:27

I promise I'll be back in a jiffy. I'll be right back. I'm with. I am with it. This is hilarious.

00:05:42:27 - 00:06:06:07

Hey, so we were talking about, you know, life and how great things are going. So I got engaged, whether So that's my life again. I just. I like, I forgot to bring it on because, you know, early Morgan showering and just pretty expensive weighing. I don't want to lose it.

00:06:06:09 - 00:06:35:19

So it has its own little treasure trove that it stays. Yeah, I was like, yeah, I had a flash. It I had a flash it for the podcast. We go, no. Yeah, exactly. I'm proud. I'm very happy to in my my new relationship and my life and how things are going. It's big, great. Like you are for sure somebody who when I started this podcast and you know, I connected with tears, it would be my producer and we were really starting to get things going.

00:06:35:19 - 00:07:03:18

You were the first person who I reached out to, but you you're doing a lot of moving back and forth. It was crazy. Yeah, yeah, yeah, yeah. So I'm really happy that you're on today because you have been you know, somebody who's actually been a big part of my life. You gave me my first hey teaching job that accelerated me being a coach and actually coaching jiu jitsu.

00:07:04:06 - 00:07:11:18

I knew it was going to work. I knew that was going to be like I did. I really did. I was like, You know what? That's going to work.

00:07:11:18 - 00:07:15:04

Is good.

00:07:15:07 - 00:07:38:02

All right, So I was just tears. It was asking. She was like, so he was technically your first boss, and you did. That was like, Yeah, I guess technically you were. No, I g I pointed you in the direction of where the money. Yeah. And then you hook me up with a training out of a Z magna ft connector.

00:07:38:02 - 00:08:03:09

That's right. You tablet. Yep. Yep. So you've been a huge part of my life. This even though we don't talk very much, which the podcast first podcast I did was with you. That's right. On your podcast Chronicles. Chronicles that was lit, you know. Yeah we but you know, I mean it was all like reciprocal because you got me into the UFC gym, you know what I'm saying?

00:08:03:09 - 00:08:05:23

And that like

00:08:05:23 - 00:08:12:17

it in a lot of ways. So that was the beginning of me finding myself in jujitsu,

00:08:12:17 - 00:08:28:23

meaning that, you know, of course, you know, start to have Gracie go to trials, finish with, you know, with heroes, get my get my black belt, you know what I'm saying? Then start teaching over at house and then get the opportunities here in the UK with Gracie.

00:08:28:23 - 00:08:49:21

But how Roundhay, Leeds and everything out here. And so, you know, it's been really just kind of fantastic. But, you know, I can't tell you how much legitimacy working at the San Bruno UFC gym has for me anywhere else that I went in the world. You know what I mean? When they were like, Well, where have you taught it?

00:08:49:21 - 00:09:10:12

And I'd be like, Well, UFC, GM, San Bruno, they like you talk to UFC gym now. Obviously they know it's not like Vegas, you feel me, but it's still, you know what I mean? And for me, you know, the the format was so open at the San Bruno spot that I had to decide how do I really want warmups to go?

00:09:10:14 - 00:09:27:24

What does it really mean? Have a warm up, You know, I mean, especially when you come from how grace is, where they try to break your soul before you even touch anybody. You know what I mean? So how how heavy? What? The warm ups. How light do I want the warm ups? What? You know what I mean. And then that led to me getting the shot to be over at USF, where I taught for a while.

00:09:27:25 - 00:09:49:00

You know what I mean? So it was just really mutually fantastic. And I appreciate you and I'm proud of you So happy to see you get your black belt. So happy to see you. You know, navigate to you. It's very impressive. It's very. Yeah, Yeah. Thank you. Thank you. Yeah. And I love everything you do. Like

00:09:49:00 - 00:10:12:11

for the people who don't know, you've been a huge leader as a, you know, a black male leader for here in the Bay Area and just throughout the U.S. with your jujitsu chess program, you had, you were putting together different art or museum exhibits, just the people that just let people know our history.

00:10:12:13 - 00:10:32:19

You know, we're actually bringing in a lot of guests here. Your podcast and your Bishop Chronicles podcast is something that I when I was driving for Uber and you were on the radio like, I just you were a staple any time I was driving to pick people up and like every single passenger I had was filling your show too.

00:10:32:20 - 00:10:58:26

They like, actually, I love what you said. Some of the stories I had on were like a little crazy. I was like, my God, these. But some of them were, you know, they were like, they were enlightening. You always start off with your your stoicism part of the day. Yeah. That's kind of why when you and you have a group going on for it was the Resilient Men group.

00:10:58:28 - 00:11:07:23

And I kind of want to understand, you know, what's that that's all about. Who are you looking to help and how are you helping these these men?

00:11:07:23 - 00:11:18:13

Yeah. No, no, no. Thank you. I appreciate that. So, you know, Bishop Chronicles, ironically, is I've been on a crazy hiatus, but me and my realm are going