 place and space for you to here and be heard. Absolutely amazing. Adisa, any last words, anything that you didn't say, anything that we didn't talk about today that you would have loved to talk about?

01:21:09:07 - 01:21:38:06

You know what? I'm going to leave everybody with this. Do not underestimate the power of meditation and prayer do not underestimate the power of meditation and prayer. I it is a big deal. Meditation and prayer has really got me through a lot of stuff. And beyond that, I'm going to say, if you have beef with anybody or somebody's got beef with you, seek forgiveness.

01:21:38:09 - 01:22:07:04

Be willing to apologize and and be willing to listen more because life is short, man. Life is short I've lost more people in my life in the last three years than in all the years before. Sometimes, you know, situations like cancer, you know, or other diseases that were that were that were foreseeable, sometimes very sudden right. But like, life is really short.

01:22:07:04 - 01:22:28:21

And sometimes people be holding grudges because they have this illusion of time. Like, I'll let it go in a few years, man. You don't know, if you're going to be here tomorrow, you don't know if that person is going to be here tomorrow. And like I've seen it happen where people think like they can hold this grudge until X happens and then something happens and that that never that beast never gets squashed, right?

01:22:28:22 - 01:22:50:29

Only your ego lets you do that. So lean into meditation and prayer and embrace forgiveness because life is short and, you know, I don't God be for nobody, you know what I'm saying? I used to I used to be mad at people and I'm I just don't have the space to be angry anymore. I might not be happy.

01:22:50:29 - 01:23:06:11

I may have lost some respect. I may not necessarily want to be in contact with you, but that doesn't mean that I have beef with you. It doesn't. It doesn't mean that I'm happy with you. It just means that your energy and the way that we engage is not healthy. That's all that means. You know what I mean?

01:23:06:15 - 01:23:21:11

And if we can find a way for it to be healthy, I'm always that door is always open for me. You know what I mean? And I'm not always the best person my damn self, you know what I mean? So I know there's aspects of me that some people, you know, are just don't want to deal with. And that's that's that's fair too, you know what I mean?

01:23:21:11 - 01:23:43:04

Like, we're all an acquired taste, you know what I mean? To some degree, we're all an acquired taste to some degree, Right. But I don't have be for nobody. Embrace your joy, embrace your peace, Look into meditation and prayer. Do it consistently. And, you know, Google Jiu-Jitsu near me. That's what you need to do and embrace your future.

01:23:43:06 - 01:24:01:01

Awesome. Well, thank you. It is wonderful to have you on. No, thank you so much. It's such an honor. I can't wait to to to blast this out on my Facebook and tweet it out to my kinfolk. I'm very proud of you. I'm grateful for you. I don't get to tell you all the time, but you really do inspire me.

01:24:01:01 - 01:24:20:25

I'll be seeing your posts, you know what I mean? And I don't always shout you out and be like, But I'm telling you, I see you. I'm very proud of you to see you get your black belt. Like. Like my heart was just, like, trembling, man, That was a fantastic thing. You know, I think sometimes we're so busy being us.

01:24:20:25 - 01:24:41:10

Whoever we are. Everybody listening. Everybody, right? We're so busy being us. Sometimes we don't realize how amazing we are. But I would tell you, you are amazing. You are amazing. We're grateful that we crossed paths and, you know, if you ever find yourself out here, I got you. And the next time I come out there, I'll definitely look you up so we can kick it.

01:24:41:12 - 01:25:01:12

All right. Awesome. That would be great. This a mess? You love everything that you're doing. And congratulations on your new life out in the UK. Thank you so much. All right. Stay blessed and I look forward to seeing this drop. I appreciate you. All right. Take care.

01:25:01:12 - 01:25:06:07

Thank you for watching. You can watch more videos like this one by clicking these links.

