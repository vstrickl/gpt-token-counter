00:00:00:00 - 00:00:01:09

it in a lot of ways.

00:00:01:09 - 00:00:04:27

that was the beginning of me finding myself in jujitsu,

00:00:04:27 - 00:00:06:20

you've been a huge

00:00:06:20 - 00:00:10:18

black male leader for here in the Bay Area and just throughout the U.S.

00:00:10:18 - 00:00:11:15

with your

00:00:11:15 - 00:00:13:23

jujitsu chess program, you had,

00:00:13:23 - 00:00:14:24

you were

00:00:14:24 - 00:00:16:10

putting together different art

00:00:16:10 - 00:00:17:24

or museum exhibits,

00:00:17:24 - 00:00:19:25

just let people know our history.

00:00:19:25 - 00:00:22:22

we're actually bringing in a lot of guests here.

00:00:22:22 - 00:00:24:07

Bishop Chronicles podcast

00:00:24:07 - 00:00:26:23

they were enlightening. You always start off with your

00:00:26:23 - 00:00:29:24

your stoicism part of the day.

00:00:29:24 - 00:00:36:27

Yeah. That's kind of why when you and you have a group going on for it was the Resilient Men group.

00:00:36:27 - 00:00:38:11

And I kind of want to understand,

00:00:38:11 - 00:00:38:26

you know, what's

00:00:38:26 - 00:00:41:09

that's all about. Who are you looking to help

00:00:41:09 - 00:00:43:14

and how are you helping these these men?

00:00:46:12 - 00:00:49:25

And so I've been out here, I've been coming back and forth for, like, four years. You know what I'm saying?

00:00:50:21 - 00:01:17:28

And so I'm supposed to get my. My, my, my, my, our my work visa. Okay, so I apply these people want to hire me to work at this school. I'm like, cool. And then the UK embassy, this woman gave me really bad information and I went with it. Lisa just got denied. That's why I'm coming back.

00:01:18:01 - 00:01:43:02

So I got to get up out the country real quick and reapply. You feel what I'm saying? And so, like, I just got this fucking apartment with my homey, like I'm right around the corner from the school that I teach that shit is laid out here and now I got to fucking leave. And so it's like, it's really weird, Bill, but I've been, you know, I've been working with this stuff called Stoic Philosophy for the last few years.

00:01:43:04 - 00:01:57:08

And like, it's a big part of it is based on this thing called the dichotomy of control, which is just understanding things you can control and things you can't. And if you can't control it, you don't trip. So I was like, All right, you got to get out. I was like, By what date? They're like, This date I just went on to redo.

00:01:57:10 - 00:02:21:24

I got my ticket, I'm headed back and I'm not tripping because I really believe, like, my future is out here and shit. You know what I mean? Like, all these happen out here. We got a big competition coming up next weekend, you know? So what competition is that it's called? I think it's called the Empire Open. It's called the Empire Opened Jujitsu here is where jujitsu used to be in the bay, like 20 years ago.

00:02:21:27 - 00:02:39:01

So it's fun. It's a fun time. Like, schools are popping up, the school gets big, then it breaks off and that school gets big and it breaks off. And so it's like you're seeing like every you know what I mean? It's just it's great. It's well, I mean, the skill level seems to be there, too, because you got what?

00:02:39:01 - 00:03:07:09

Well, I'm going to say just a whole UK. I'm not going to say, Are you in England or what? Yeah, I'm in. I'm in Leeds, which is like about 3 hours north of, of London, you know what I mean? And so, I mean, this is where Roger Gracie lives, you know what I'm saying? He lives in London saying like and I think also that people think of England as like super, super white, which it always will be, but it's also way more integrated than people think.

00:03:07:11 - 00:03:28:24

So there's a lot of Irani, a lot of Dagestani, a lot of Japanese, you know what I'm saying? So there's a lot of judo out here. But I think people I mean, you know, Futaba. Futaba, the owner of the gym, she's from London. I mean, she she spent a lot of her life living on one. Exactly. And it's very it's much more multicultural than you would think.

00:03:28:27 - 00:03:46:04

And just like, I think one, you know, the reason why I think, you know, and my instructor, Gumbi from Heroes martial Arts, I he really pointed out that, you know, the reason the Bay is so dangerous is because so many different kinds of people are there. you do kung fu? Yeah. In Chinatown, you can see what's up.

00:03:46:09 - 00:04:07:13

you do judo. There's Willie Cahill, There's San Jose State. you do jujitsu. There's a whole bunch of Gracie's. And you know what I mean? And they're students. Students? You know what I'm saying? So, like. Like London and England in general is the same. You know what I mean? A lot of sick ass wrestlers from Turkey and stuff are out here, you know what I mean?

00:04:07:13 - 00:04:26:14

And it changes the way that jujitsu gets executed, you know? I mean, because the entry point becomes different, right? Like a Dagestan is going to grapple different than a judoka. You know what I mean? And if these things like making what the standup game of of the UK is, then it changes everything. So it's really powerful. Yeah, yeah, yeah, yeah.

00:04:26:15 - 00:04:50:13

That sounds cool. Yeah. I mean, Fiona, the frickin phenom right now is from the UK. From Wales? Yeah. Yeah. And plus they have the, the Polaris Pro, which is just an amazing series where they really try to like, highlight and showcase women but just like justifies themselves are very high, high energy. The crowds, they get it, you know what I mean?

00:04:50:13 - 00:05:19:13

Like it's. Yeah, it's really cool. Yeah man that's. I haven't been to England in so long. I did I, I went once with my mom in my twenties. I'm almost, you know, 40 now. We're not going to talk about that. I'm living life to forget at the age I live with my mum. Have a good time. So whatever you look like, you still in your.

00:05:19:16 - 00:05:35:05

You know what I'm saying? Would move in. You know what I'm saying? It's good. You know, I try. I do my best. I do my best. You know what? I forgot something too. I forgot something. I'll make this podcast announcement real quick. I'll be. Well, take us as long as it took us to get set up for this.

00:05:35:05 - 00:05:42:27

I promise I'll be back in a jiffy. I'll be right back. I'm with. I am with it. This is hilarious.

00:05:42:27 - 00:06:06:07

Hey, so we were talking about, you know, life and how great things are going. So I got engaged, whether So that's my life again. I just. I like, I forgot to bring it on because, you know, early Morgan showering and just pretty expensive weighing. I don't want to lose it.

00:06:06:09 - 00:06:35:19

So it has its own little treasure trove that it stays. Yeah, I was like, yeah, I had a flash. It I had a flash it for the podcast. We go, no. Yeah, exactly. I'm proud. I'm very happy to in my my new relationship and my life and how things are going. It's big, great. Like you are for sure somebody who when I started this podcast and you know, I connected with tears, it would be my producer and we were really starting to get things going.

00:06:35:19 - 00:07:03:18

You were the first person who I reached out to, but you you're doing a lot of moving back and forth. It was crazy. Yeah, yeah, yeah, yeah. So I'm really happy that you're on today because you have been you know, somebody who's actually been a big part of my life. You gave me my first hey teaching job that accelerated me being a coach and actually coaching jiu jitsu.

00:07:04:06 - 00:07:11:18

I knew it was going to work. I knew that was going to be like I did. I really did. I was like, You know what? That's going to work.

00:07:11:18 - 00:07:15:04

Is good.

00:07:15:07 - 00:07:38:02

All right, So I was just tears. It was asking. She was like, so he was technically your first boss, and you did. That was like, Yeah, I guess technically you were. No, I g I pointed you in the direction of where the money. Yeah. And then you hook me up with a training out of a Z magna ft connector.

00:07:38:02 - 00:08:03:09

That's right. You tablet. Yep. Yep. So you've been a huge part of my life. This even though we don't talk very much, which the podcast first podcast I did was with you. That's right. On your podcast Chronicles. Chronicles that was lit, you know. Yeah we but you know, I mean it was all like reciprocal because you got me into the UFC gym, you know what I'm saying?

00:08:03:09 - 00:08:05:23

And that like

00:08:05:23 - 00:08:12:17

it in a lot of ways. So that was the beginning of me finding myself in jujitsu,

00:08:12:17 - 00:08:28:23

meaning that, you know, of course, you know, start to have Gracie go to trials, finish with, you know, with heroes, get my get my black belt, you know what I'm saying? Then start teaching over at house and then get the opportunities here in the UK with Gracie.

00:08:28:23 - 00:08:49:21

But how Roundhay, Leeds and everything out here. And so, you know, it's been really just kind of fantastic. But, you know, I can't tell you how much legitimacy working at the San Bruno UFC gym has for me anywhere else that I went in the world. You know what I mean? When they were like, Well, where have you taught it?

00:08:49:21 - 00:09:10:12

And I'd be like, Well, UFC, GM, San Bruno, they like you talk to UFC gym now. Obviously they know it's not like Vegas, you feel me, but it's still, you know what I mean? And for me, you know, the the format was so open at the San Bruno spot that I had to decide how do I really want warmups to go?

00:09:10:14 - 00:09:27:24

What does it really mean? Have a warm up, You know, I mean, especially when you come from how grace is, where they try to break your soul before you even touch anybody. You know what I mean? So how how heavy? What? The warm ups. How light do I want the warm ups? What? You know what I mean. And then that led to me getting the shot to be over at USF, where I taught for a while.

00:09:27:25 - 00:09:49:00

You know what I mean? So it was just really mutually fantastic. And I appreciate you and I'm proud of you So happy to see you get your black belt. So happy to see you. You know, navigate to you. It's very impressive. It's very. Yeah, Yeah. Thank you. Thank you. Yeah. And I love everything you do. Like

00:09:49:00 - 00:10:12:11

for the people who don't know, you've been a huge leader as a, you know, a black male leader for here in the Bay Area and just throughout the U.S. with your jujitsu chess program, you had, you were putting together different art or museum exhibits, just the people that just let people know our history.

00:10:12:13 - 00:10:32:19

You know, we're actually bringing in a lot of guests here. Your podcast and your Bishop Chronicles podcast is something that I when I was driving for Uber and you were on the radio like, I just you were a staple any time I was driving to pick people up and like every single passenger I had was filling your show too.

00:10:32:20 - 00:10:58:26

They like, actually, I love what you said. Some of the stories I had on were like a little crazy. I was like, my God, these. But some of them were, you know, they were like, they were enlightening. You always start off with your your stoicism part of the day. Yeah. That's kind of why when you and you have a group going on for it was the Resilient Men group.

00:10:58:28 - 00:11:07:23

And I kind of want to understand, you know, what's that that's all about. Who are you looking to help and how are you helping these these men?

00:11:07:23 - 00:11:18:13

Yeah. No, no, no. Thank you. I appreciate that. So, you know, Bishop Chronicles, ironically, is I've been on a crazy hiatus, but me and my realm are going to make it pop up soon.

00:11:18:13 - 00:11:34:21

And everybody who's going, you keep saying that and I don't. And I agree. I agree. I've been dragging. But I've been dragging because I've been living and trying to figure out, you know, what exactly am I doing with the podcast and what kind of content do I want to deliver. But the Resilient Men's Group was kind of born from that.

00:11:34:21 - 00:11:58:06

And so what it's about is, you know, I got into the stoicism because I had a near-death experience, and then right after that I ended up getting divorced. And so like that whole situation shook up my sense of my identity. Like, I really didn't know who I was because I had been married for 23 years and I had known her for 30 years.

00:11:58:06 - 00:12:23:11

Right. And I'm 53, so I more than half of my life like, who am I? Like, if I'm not married and if I'm not, you know what I mean? Around my kids all the time. Like, who am I? And so it took me a while and Stoicism played a significant role in me finding myself. My direct link in the stoicism actually comes through jujitsu through a guy named Abraham Marti shout out to the Dominican Republic, who he was doing a seminar at Heroes.

00:12:23:11 - 00:12:42:01

I was supposed to go meet with him and my split happened, like right before the weekend he arrived and he was expecting me to be there to interview him. I was like messed up. I was not at the interview. A nobody. And he was like, Bro, he called like, Where are you at? And I was like, I'm having a split.

00:12:42:01 - 00:12:53:28

It's a bad time to go. And then he was like, Bro, you got to be more stoic. And I was like, What? He was like, You got to be more stoic. And I was like, What does that mean? Like, I don't I don't know what that means. And he was like, Man, you know, you got to look into it.

00:12:53:28 - 00:13:09:04

But, you know, bottom line is, my life isn't perfect either. I got all this other stuff going on, but I'm here and I'm training and you need to be here. You need to be training. Now, we're not doing the interview. And so when I got off the phone, I immediately went on a YouTube and started looking at Stoicism, which is something I never really did.

00:13:09:04 - 00:13:32:28

I never really used YouTube before then to find out a thing. But obviously YouTube had tons of different cool things on Stoicism, and that led to me just diving into the wormhole of that philosophy system. And what a lot of people don't know is because of people like, you know. AK Black, also known as Jim Wilson over there at Physique Man, it's like I got into reading about philosophy at a really early age.

00:13:32:28 - 00:14:04:08

So I had read a lot of the Pre-socratic stuff. I read Aristotle, I had read Plato, I had read lots of Eastern and Western philosophy like in Depth, Confucianism, Daoism, you know what I mean? Lots of different stuff. So it was easier for me, I think, to understand stoic philosophy. I don't want to say better than others. I'll just say because of all the philosophy I had been reading, it was easy to understand and I became a serious believer in the way that philosophy works, which is around a lot of practice.

00:14:04:10 - 00:14:28:17

Like it's not that stoic ideas are cool because you'll find people online who quote Marcus Aurelius or Seneca or whatever, but it's really that like they have different practices for different things you're trying to do. So if you struggle with fear, they are stoic practices for fear. If you if you struggle with anger management, they have ways to curb your anger, sadness, ways to like, look at your sadness in a better perspective so that you're not harming yourself.

00:14:28:17 - 00:14:45:25

You know what I mean? I know a lot of people that cut themselves that you know what I mean? That I've tried to kill themselves, you know, even recently and stuff like that. Right. And even even express your joy in moderation. Right. Like, it's not that you're not a joyful person, but like, let's take let's take just the bay, for example.

00:14:46:01 - 00:15:18:07

Right. If if the 40 Niners lose the Super Bowl stuff going to be on fire. Right. If they win a Super Bowl stuff on the on fire. So these are two different extreme expressions of anger and joy. Right. So it's about moderation. And once I started doing those practices, my life just became much better. And I started studying it so heavily that within a few years I was able to like lecture at it at Stanford University, which was amazing, you know?

00:15:18:09 - 00:15:38:21

And then they invited me back to do another talk. And I just recently did a talk out here in the UK, I think called the next 45, which is created by this amazing guy named Mike Bates, who is is the is the owner of the school that I do some work at right now called Gracie Bar Roundhay Leeds.

00:15:38:23 - 00:15:56:05

It's an amazing school. They have 500 students, 500 like this school is big and it's rapidly growing. Yeah, I know, but this guy is amazing. And he created this thing called the next 45, where people get to 45, they start falling off, thinking their lives over, thinking they're done. And he's like, No, you got to look at the next 45.

00:15:56:08 - 00:16:17:29

And so he invited me to be the keynote speaker at this men's retreat, and it was fantastic. But one of the reasons he invited me to do this men's retreat and be the keynote speaker was because I had been doing the Resilient Men's Group, which is a group where men from all backgrounds all over the UK show up and we have different conversations around what's bothering us.

00:16:18:06 - 00:16:42:24

And then what I do is I weave stoic solutions into the conversations. It's stoic practices, right? And it's been going really, really good. So, you know, if anybody is interested in joining the Resilient Men's group, just follow me on Instagram at Bishop Chronicles. If you follow me at Bishop Chronicles, the links to get on and be a part of it are really amazing.

00:16:42:26 - 00:17:03:18

And you know, it's a beautiful time. I'm going to be coming to the Bay Area soon and be able to hang out and I may do some resume and stuff while I'm there. We'll see. But it's a beautiful time and I'm grateful to be be helping men help themselves be better men. Like I'm really working to make sure that people are not trying to follow me.

00:17:03:20 - 00:17:30:26

I'm helping a resilient men's group to help introduce them to themselves. Right. Like I know that I am, you know, a teacher of jujitsu. I'm a teacher of meditation. I'm a teacher of chess. Right. And I have a group called 64 blocks, which is about that fusion. But really, the the reason why I'm slow to do a lot of stuff is because I don't want people following me.

00:17:30:28 - 00:17:50:29

I want them following themselves, their own heart, their own mind, their own aspirations, their own goals. I don't want them to be like me. I want them to be like themselves and the only reason I introduce and push stoic philosophy, meditation and chess and jujitsu is because these are tools that I believe introduce the individual to who they naturally are.

00:17:51:01 - 00:18:08:29

Right? So I don't want a carbon copy of me. I tell my students all the time, Don't be trying to move like me on the mat. I'm going to give you a foundation and a blueprint of how to move, but I will introduce you to jiu jitsu. But you will introduce me to your jujitsu based off your body type, your mindset, your in your creativity.

00:18:08:29 - 00:18:35:07

Right being a replica of me isn't what I need on the mat, and it's not what the world needs. That's a beautiful desire. And yeah, I mean, we can only teach from what our own personal experience is and what we know We can't teach from outside of those things. And so I think you just reinforcing, hey, this is, this is what I know, this is how I can teach you to help you build your foundation.

00:18:35:10 - 00:19:05:15

But really this path is your own. Make it your own. Don't be me. I love that. And I think it's a lot different than the traditional ways that martial arts has been taught and how it's been taught to us. And I also really want to just go back and re-emphasize, you know, how the reason why have you on and talking about the Resilient Men's project is because mental health is a very important subject to me.

00:19:05:18 - 00:19:40:26

And I think that men don't find it easy for them to have a group or a person where they can actually be authentic and share the expressed their emotions. Because I think it's pushed, you know, society tries to condition a sense of toughness out of them. So any type of weaknesses or vulnerability is seen as a weakness. And I think, you know, we've had some really great men that we thought were on top of their game to take their own lives.

00:19:40:28 - 00:20:02:15

And to me, I just find it heartbreaking to hear that, you know, that like I there's a lot of great, wonderful men in my life who I want them to know. You know, sometimes mine is an ass, but she loves you, you know? Come to me and talk to me about anything because I want to see you here.

00:20:02:15 - 00:20:36:14

Even on the days that you might be pissing me off. Right? Still wants you to be here with us. So. Yeah, you know, as a no. Yeah. No, I appreciate that. You know, I think that, you know, men do struggle. I think that, you know, everywhere. But especially, I think like in the West, meaning like, you know, America and in the UK and, you know, most of the world of real black men are not encouraged to show anything but toughness.

00:20:36:17 - 00:21:09:20

Right. But what happens is, is a lot of that so-called toughness leads to alcoholism, leads to a lot of drug use, leads to a lot of self-harm in soft ways and in slow ways that don't look as painful as they end up. Right? So you have guys that, you know, work themselves to death, just to death, eat themselves into an early grave because they're not really willing to just say, you know what, this isn't the life that I want or this hurts too much or I endured this thing that I can't shake.

00:21:09:22 - 00:21:28:12

You know what I mean? So the Resilient Men's group is meant for dudes to show up, say their truths, deal without judgment, you know what I'm saying? And express their pain and their joy and their confusion. You know what I mean? Sometimes just confused about what they want to do with themselves or how they got to wherever they are in their life.

00:21:28:19 - 00:21:52:29

And that's all okay, right? That's all okay. You know, like yeah, So yeah, so, you know, we have open conversation and then I sprinkle in a little stoicism, you know, and it's working really well, you know, and I'm I'm trying to get one started in America. And so that's one of the things that I'm going to do when I come out there, hopefully is set up some resilient men's group events while I'm there and, you know, keep it going.

00:21:52:29 - 00:22:22:24

But, you know, mental health is really important. And, you know, I appreciate you for for even even caring because, you know, it's been more than one occasion where sometimes people in jujitsu, like they've reached out to me about stuff. But I didn't really know, you know, like this one guy, many years ago. I bet you this is over ten years ago, this one guy hit me up because I had posted this thing called The Book of Forgiving by Archbishop Desmond Tutu and his daughter.

00:22:23:02 - 00:22:40:26

And it's about how after dealing with very heavy things, people were able to forgive. And it talks about the science in forgiving. What does forgiveness due to the human body? What does it do to the human brain? That's what this book is about. So he hit me up and he was like, amen. And looks like a pretty cool book.

00:22:40:26 - 00:22:54:04

And I was like, Yeah, that is a good book, man. You should get it. And after you read it, talk with me. He was like, Okay. He was like, Yeah, I've been going through some stuff, but he really, you know, he, he kept it really mellow. And then I didn't really follow up because, you know, I didn't really know him.

00:22:54:04 - 00:23:12:13

We just talked nominally. I might see him at class once in a while, and then one day he took his own life and I was totally I was like, was he asking for help? I didn't read it, but he didn't really ask for help, you know what I mean? He was just saying whatever. And that was just like, dang.

00:23:12:13 - 00:23:35:20

And so, you know, it's a it's a hard road and we all suffer, you know what I mean? And like, I saw this really interesting conversation online and it was about in a world where people aren't getting married as much and most kids are getting raised in households without a dad. Like do fathers actually matter? And it was a strange, really cool quote by this psychologist.

00:23:35:26 - 00:24:06:26

And she was basically saying that like the ultimately that the value of any father is rooted in the mental health of that parent. Right. So like, if the dad is not mentally healthy, it might be worse if he's around. Yeah, right. And it's really deep, right. That like the quality of the father ultimately is based on the mental health of the father and the quality of the mother is ultimately based on the mental health of the mother.

00:24:06:26 - 00:24:29:07

And we're living in a world that's crazier by the minute. So, you know, we all need these resources, we all need therapy, we all need an outlet, we all need philosophies. For me, it's stoicism. For somebody else, it might be Buddhism for somebody else, it might. It might be meditation or whatever. But we need to be looking to find solutions to discover and cultivate our joy and our peace.

00:24:29:10 - 00:25:11:25

Deliberately inconsistent. Yeah. Amen to that. To man. That's deep. Yeah, it it it, it. I try to be really sensitive about, you know, that type of, you know, suicide and things of that nature, because I've gone through it myself, my own struggles. And I know like, people are ashamed to ask and reach out for help in those instances and they or they don't they're ashamed or they don't really know how to ask or who to ask.

00:25:11:28 - 00:25:27:24

So, no, you know, how do you even explain what you going through when you haven't really thought about it? How did I get here? How did I get to this pain? Why I don't want to harm myself? Why do I think my life don't matter? You know what I mean? Like, it's hard to even know that stuff. You know what I mean?

00:25:27:27 - 00:25:57:23

Yeah. So. No, I agree. I totally agree. Yeah. So. Yeah, I, I, yeah, I just yeah, it's a very as is the subject matter that I care about very deeply. And, and that's definitely, you know, I've had a a lot of different things that sparked this podcast, you know, my first podcast guest was my friend goalie and she's a therapist.

00:25:57:23 - 00:26:31:07

She's a she. Well, she, she doesn't have her license as a licensed psychologist yet, but she has her master's in psychology and she's practiced. She's just taken the test to get her her license here. And so she was my first podcast guest because last year when we reconnected, we had this deeply spiritual conversation about coaching and mental health and spirituality and just listening to her perspective on how she was speaking about it.

00:26:31:09 - 00:26:57:04

My whole physical body was vibrating, and I don't think I've ever had that experience with somebody where I'm talking to them and their words that they're saying moved me so much that I just feel like my whole entire aura and spirit changed to the point where I was vibrating. Yeah, exactly. And I was like, Go, got to have you on this podcast.

00:26:57:04 - 00:27:32:08

You know, we didn't get unfortunately, it was the first podcast, so we didn't get that deep. We were mostly just catching up, talking women and jujitsu and all those other things. So the guests are missing out, but we'll have goalie back on again. But yeah, the yeah, know, it's powerful, you know, and I mean the thing is too is man, I feel real bad right now because I'm blanking on a brother's name, but he's the guy that runs off clothing and he does all the cool stuff down at Sano Couch.

00:27:32:08 - 00:28:04:12

Sarah, You know, and I went down there one day because I was working on some stuff promoting one of the smokers that Dorian Cartwright over at Gracie Brands. You know, he always runs cool smokers. And somehow I went over there to promote the smokers and drop off some posters. And I didn't even realize that, you know, that dude, his background is actually mental health and is actually in helping incarcerated youth, boys and girls all over.

00:28:04:12 - 00:28:25:07

I think I'm probably messing up, but it was up in like, I think Oregon and I think Hawaii and some other spots. And one time we were talking and he was talking to me, I think about a woman who had passed away after taking her own life in jujitsu. And I was like, Why do you think that that happened?

00:28:25:13 - 00:28:45:10

Then he was like, Yeah, because jujitsu is not a replacement for therapy. And I was like, and it's deep because, you know, there's a lot of people who work out all the time and they'll be like, you know, the gym is my therapy, right? And there's people that'll be like, Yo, bro, if I'm not on the mat, I'm just not right to match my therapy, bro.

00:28:45:12 - 00:29:24:07

Like that makes sense to a degree, but real therapy is still cool, right? Like, don't, don't miss, don't, don't misconstrue the beauty of those experiences. In fact, my therapist said I think he used the term called cognitive bypassing, right. Where people use their faith so much that they're still not really dealing with themselves. Right. I will use stoic philosophy to, well, that looks like this and that looks like that, but you're still not really dealing with yourself and your issues and things like that.

00:29:24:09 - 00:29:51:22

So, you know, it's crucial that we do. It's crucial that we do. And so, you know, it's it's powerful, man. It's powerful. And we need to, you know, use jujitsu to enrich our hearts and our minds and our bodies. But but still take time to be deliberate about the emotional and psychological help that that we need. Yeah. Yeah, absolutely.

00:29:51:22 - 00:30:19:28

Absolutely. It becomes you know, I know for myself, when I first started doing jujitsu, I used jujitsu as my escape haven until I couldn't till I got to that point where I talked about, you know, what I talked about with my mental health issues. And it was to the point where it was like it was either I remember getting to that point and I was like, I either am going to live or I'm going to die.

00:30:20:01 - 00:30:40:18

I'm either going to choose to live or I'm going to choose to die here at this point right now. And failure or die to me was not an option because I still there was still hope for me. I still wanted to see more of my life happen. So in my head I was like, But, you know, failure here is not an option.

00:30:40:24 - 00:31:03:29

So how do I get myself out of this hole? And I didn't have the tools or the answers at the time. I was just scraping and holding on to any piece of knowledge that any person that I had in my life, You know, my mom during that time was a huge support. I don't know what I would do without her.

00:31:04:02 - 00:31:25:17

My coach, Darren at the time was a huge support. That's one of the reasons why I'm so tight with him, because it was like in the darkest moment of my life, you had my back and that's a big deal for me now. That's the same for me. Yeah. You meet Gumby, hit me up, and he heard me being fragile and he was like, Yeah, you need therapy.

00:31:25:17 - 00:31:41:20

Like, he was just like, off the top. He was like, I'm going to pay for the first session. Call this number, Get on it. You know what I mean? And I did it. Yeah, that was crucial. You know, one day I was like, on the real life, I was looking around the house for stuff to offer myself with.

00:31:41:22 - 00:31:59:21

And my dad just happened to call, and I wasn't even talking to him about anything crazy, But I think he could just hear the darkness. And he was like, What are you doing for dinner tonight? I was like, Nothing is all right. I'm gonna come over and get, you know, was like, okay, like he saved my life that day.

00:31:59:28 - 00:32:24:26

I tell him that, bro, you saved my life that day, because if you wouldn't invited me over for dinner, that would have been it. You know what I mean? Yeah. And I like it's hard for all of us. I think that, you know, there's a lot of reasons that we complain about the American school system, but one of the things that we know they don't do is they don't really address the emotional needs of the young people and teach them how to deal responsibly with what they feel.

00:32:24:28 - 00:32:56:05

And so I hope that in the future, you know, that changes. And I just hope to be a have a hand in that, you know, helping young people find value in themselves and worthy of contemplating and cultivating the best aspect of whoever they are, you know, before they fall for how many people do or don't like them. On Tik Talk or YouTube or IG, you know, that they can find and love themselves.

00:32:56:08 - 00:33:29:28

And, you know, unfortunately, you know, many adults, we just we still struggle with the same thing. You know. Yeah, yeah. Finding value in things outside of ourselves and external things. Right. How many likes do I have? How much success can I gain, How much how hard can I work to be valued? Well, those things, what I found to keep myself out of that hole is finding value in myself intrinsically, within the things that I that I am not by things that I do.

00:33:29:28 - 00:33:56:02

You know. And so that's shifting where I put my energy and where I put my value for myself really helped me release a lot of in my life, not just negative people, but negative thought patterns, led negative habits, negative behaviors, because I just yeah, at anything is like, who am I being in this moment? Not what can I do?

00:33:56:02 - 00:34:20:04

What can I do for this person? How can I be for this? If I'm if it's for somebody else, how can I be in this relationship? How could I be a better girlfriend? Not what can I do for you? Yeah. And, you know, I think a lot of it too, is like society works so hard to keep us distracted that it's very hard to figure out who we are when we're always in our phone.

00:34:20:04 - 00:34:40:21

You know, I struggle with phone addiction still, you know what I'm saying? But like, you know, when I was at the next 45, even though I had really happy to do the keynote talk, which was called Stoic Philosophy, Life and love, like looking at stoic philosophy through the lens of love, like what does it mean to be loving and to stoic?

00:34:40:21 - 00:35:08:13

And there's different kinds of stoic love, love just in the in that philosophy. But like, my my best time was actually paddleboarding on a lake by this whole thing of lily pads and lotuses. And I was just by myself. Yeah, we just would. And I was like, Yo like coasting by this whole, like 30 or 40 feet thick of lily pads and lotuses.

00:35:08:17 - 00:35:30:12

It was just perfect silence. All I could hear is like my paddle. Like, that was the best thing. That was the best thing. Even more than, like, how happy I was with my talk. That was the best thing for me, right? But we live in a world where being by ourself seems dumb, being by ourself seems you being too nerdy or you being too weird or whatever.

00:35:30:15 - 00:35:53:01

But really, like if you look at a lot of Buddhism and Confucianism specifically, right, they talk about how hard it is for people to be by themselves without music, people to be by themselves, without, you know, things to distract them. Right. And so, like, we have to learn to be at peace with who we are. And then everything starts to open up.

00:35:53:03 - 00:36:19:20

Yeah, I think being in nature is super helpful for that because in the home, it's not just easy for us to be distracted by all of the technology and the electronics, the TV, our phone, things that we have to do around the house to clean. But we're already so removed from nature being, especially if you live in an urban environment, right?

00:36:19:20 - 00:36:48:13

So soon as I set foot on the sand or put my feet in the grass, I get a pletely different energy shift and I don't need music at that point. My music is the way I leaves or it's be yo, you spit in bars right now because like, like before I, before I before I started coming back and forth out here a lot and trying to hang out here.

00:36:48:16 - 00:37:11:10

I used to, I used to jogging Linda Mah beach in Pacifica and I would get up outrun full span of the beach, down one side and back and then I would take my shoes off and I would walk with the waves just kind of going like, like ankle, ankle high, you know what I'm saying? And I never better than when I was doing that.

00:37:11:12 - 00:37:31:23

You know, I never felt better than when I was doing that. And there's this thing if you go on YouTube, I think it's called the Shuman residence Resonance, and it is the frequency of the earth. And so a lot of times what I'll do is I'll sit on the earth or stand barefoot on the earth. It's called grounding, right?

00:37:31:23 - 00:37:53:08

Because the energy from the earth, it goes through your body. I'm not talking like hippie stuff. I'm talking about life, actual, measurable science. It's called grounding. And it's good for your body to be on the earth so you can stand on grass or sand or whatever it's called grounding. Right? And I would listen to the Earth's frequency. It's called the Schumann Resonance.

00:37:53:11 - 00:38:22:01

And if you listen to that with headphones on and you just sit still, it's unbelievable. It's unbelievable. And it's incredibly good for your actual brain. Right? So, you know, the Stoics were about nature, the Buddhists were about nature. The Sufis were about nature. And you find, you know, even if you look at things, you know, ancient like Freemasonry, you find that a lot of the things that they were doing were connected to reflecting nature.

00:38:22:04 - 00:39:11:23

And at that time it was becoming modern society. And so it's very powerful to see how being still in nature has moved so many societies. And then we get to this place where so high technology that we've forgotten our own origins, right. And forgotten own roots, it's powerful. Well, I'm going to try to not be so political, but it's going to be hard with my this next statement, which is it reminds me a lot of, you know, just African ancestry and how we were removed from that, from like those traditions and that history and those spiritual practices in a sense.

00:39:11:23 - 00:39:37:10

And and it's like, you know, I wouldn't say I'm doing a lot of research to get back to that point, but I love I do love technology for connecting us to those different cultures so that I can see and I can understand, this is what, you know, people from this area would do, like especially as a black woman, this is how we would actually take care of our hair.

00:39:37:13 - 00:40:05:28

This is how we would take care of our bodies. This is how we would eat. This is how we would connect with nature. And even though, you know, I'm still removed here in the United States, I'm using technology as a way to open myself up to different worlds. It's still it's humbling to know how removed we are from all that ancient history, that ancient knowledge that served us to be more grounded, as you said.

00:40:06:00 - 00:40:30:20

Yeah. No, no, no. It's it's a big deal, you know? And so this is where we bring it back to jiu jitsu, right? Because a lot of my health now actually comes from Gracie Jujitsu. Right? You know, I was lucky enough to meet and interview Ariel Gracie back when the UFC was brand new, back when Boyce was in there mopping and choking Fu's out.

00:40:30:22 - 00:40:53:25

And, you know, I remember Maureen telling me about the Gracie Diet. You know, I remember Marianne telling me about the importance of juicing and saying, you know, what is it, Guarana, that that other like Berry, You know what I'm saying? And so, like, I remember having Guarana for the first time and they were laughing at me because I hadn't eaten that day.

00:40:54:00 - 00:41:35:12

And then I was I was drinking. They were like, this was about to be off the off the Richter, you know. And I was but, you know, I juice now like everybody knows me for juicing my actual juice. Not juicing like, you know. Yeah, yeah. I'm not juice, you know, I just, I had in high school and still here, but, but I, you know, I juice a lot like almost every day, you know, I have natural juice and then I'm Bishop Chronicles.

00:41:35:12 - 00:41:54:18

I'm pretty sure it's still up. I got to interview Ralston Gracie, who basically became a fanatic about the doctor save diet, and he's blended it with the Gracie Diet to improve health and stuff like that. And so he and I, you know, that's my brother for real. Like we still talk about all of that stuff and more every day, right?

00:41:54:18 - 00:42:19:06

But this house, it is interesting because I've known I've I've met Halston when I was a white belt and he really randomly pops up like, I'll just see him like, real like, wow, Nice to see you. Real. It is kind of crazy. I got to look where you are. Yeah, you're right. Right. He's just doing amazing and he'll just pop up Jake the subject.

00:42:19:06 - 00:42:40:00

So. Yeah, true story. So I'm chilling, right? I'm like, Yo, man, I got to. I got to you know, I was. I was taking this this woman I'm still with on a on a great date. I got to figure some cool. So I'm like, I'm to take her to Muir Woods. We're going to walk. We're going to go for a walk in the woods, maybe go to your beach.

00:42:40:03 - 00:43:02:08

So we walk in. Muir were chillin when the cuts of Muir Woods. I don't even know where I was, You understand? I literally don't. We're walking around. It's a great day. you want to have a sit for a bit? Yeah So we're just sitting on this bench and we're chillin now. I had told Ross and I said, Hey man, you know, I won't be chilling with this lady.

00:43:02:08 - 00:43:20:15

And, you know, I was thinking maybe like, have you ever, like, cook dinner for somebody? But like, I was like, what if I broke you off? Right? Left you at the house? I'd go on the whole walk thing, and I come back and you, like, cook dinner. He was like, Yeah, we can figure that out. But our schedules are too crazy and we didn't figure it out.

00:43:20:21 - 00:43:47:08

So anyway, I'm sitting here chillin, we talking on a bench, and all of a sudden we see this dude in the distance and he's running with his shirt off at a really fast pace and he gets close. And I'm like, Ralston, He's like the super lady. it's like he looks at me. He's like, Is that. Is that.

00:43:47:08 - 00:44:11:12

What were you talking about? I was like, Yeah, that's her. It's like it was, yeah, you know, but we couldn't get figured out yet. It was hilarious. But Ralston is so wise. He's always studying and he's always, like, trying to study the body, food, the earth. And he's just. He's an impressive dude, man. He is an impressive dude.

00:44:11:12 - 00:44:30:24

Match That shot to that. Yeah, yeah, yeah, I always have. I don't. You know, we're not tight like you. Like I just see him. I'll just see him randomly. But I always have cool converse Asians with him. You know, any time I do talk to him and catch up and it's kind of like, you're still traded, you know?

00:44:30:27 - 00:44:56:01

Yeah. This is amazing, man. Yeah, yeah, yeah, yeah. That's cool. But yeah, this is how jujitsu can save your life, right? That there are limits to what you do you can and should do for you. Maybe mentally and emotionally. And you should always look for therapy, look for support groups and things like that. But what jujitsu does do to enrich your mind, to open your heart to your own potential, to to to test your body and help show you what you're capable of.

00:44:56:08 - 00:45:18:01

I don't think there's a better tool in the modern world than jujitsu for that. I just don't. And you know what? Look, this is no disrespect to anybody who likes hoops or soccer or Parcheesi or whatever they get into. I'm just saying I don't think that anything will help you grow as quickly into learning about who you are and what you're capable of as Brazilian jiu jitsu.

00:45:18:03 - 00:45:44:12

You know, I just don't. Yeah, I, I agree. And I think you know, we're both bias and I'll do that. Yeah you know I'll be open to bias but I it too because you know there's always this social component with a lot of group sports. You know you have a social component to basketball team football team, you know any anything where there's a team involved.

00:45:44:14 - 00:46:18:27

I just find that the the connection with martial arts specifically and jujitsu is different because it's deeper. It just comes from way. Yeah. You know, and the school that I'm on right now you know Gracie Eberhardt Roundhay Leeds is an unbelievable school because the guy who moved is, like I said, Mike Bates and T, you know, they're like, yo, like this is a community project first and a jujitsu school second, you know?

00:46:18:27 - 00:46:43:02

I mean, like jiu jitsu is secondary to building the community. So there's so many kids, so many families, so many moms, so many dads that come and train. And it's just fantastic. I stick to see how the community engages itself. I just you know, I haven't seen anything like that. And I'm from the Bay, where is probably one of the best places on earth to learn jiu jitsu ever.

00:46:43:07 - 00:47:05:14

OC is the San Francisco Bay Area. But the level of community that I see being intentionally and consistently cultivated by Mike Bates and TI and all the coaches over there at IRL, it's amazing that anybody would tell you that when they come to GBR, they're like, This place is different and they're right. And it's not that like, you know, it's a relatively new school, right?

00:47:05:14 - 00:47:26:29

So most of the students there are Blue Bulls. I think they only have like one purple belt. And then, you know, it's it's a few black belts, you know what I mean? Teaching, you know, and a lot of blue belt coaches teaching. But like, man, like what you get out of those classes in terms of community, I just I haven't experienced it anywhere else.

00:47:26:29 - 00:47:56:15

And that's why I love the school so much. Yeah, that's amazing. That's amazing. Yeah, It's a beautiful thing. Well, so what are you have any memorable stories from, you know, that commuting build community building experience or even just in your life any anything from your life in jujitsu? I know you have a lot on the podcast on Bishop Chronicle podcasts.

00:47:56:15 - 00:48:35:29

If people want to follow in one anything you want to share. Four for my podcast. Yeah, yeah, let me think. Let me think. Community building Community crazy. So this is going to sound maybe corny to some people, but I really love this experience. So there's there's a young boy at the school and he has two stuffed animals and he brings them to every class and we give each other fist bumps and stuff all the time.

00:48:36:01 - 00:48:58:15

But he always makes sure. He always asks if I can give his stuffed animals this once before and after class. And so one particular day he comes in and he is crying. I mean, this boy is shattered like he's in his gear and he's just like, and I'm like, What's wrong, bro? Because he doesn't even want to get on the mat, like, what's wrong?

00:48:58:15 - 00:49:23:18

And he's like, my mom left Jeffrey at home. I'm like, What? Jeffrey can't make it to class, and I don't want to be here without him. And I was like, okay. I was like, But check this out. I was like, I miss Jeffrey, too. But what if, like, you got to go back to Jeffrey and like, all he's going to want to know is how was class today?

00:49:23:25 - 00:49:37:04

You think he's going to be happy? You just tell him he's over here crying and not learning. He's going to want to see what you showed him. And if you stay over here crying all day, you're going to be like, I was crying all day. And Jeffrey is going to be like, Well, you didn't learn nothing, and that's going to be bad, man.

00:49:37:06 - 00:49:49:29

Why don't you just come on the mat and chill and do that? And he did. He got on. He had a great class and I was like, All right, I want you to tell Jeffrey I said hello. You know what I'm saying? And show him what you learned today. And he's like, okay. And he was like, super happy.

00:49:50:02 - 00:50:16:21

So then like, really that and Jeffrey is a SEAL and he had a snow seal, a small snow seal named Jeffrey Junior. And he was like, Look, now I got Jeffrey and Jeffrey Junior, I need you to give them fist bumps. So now I got to give him this. And once there, but like to see him be resilient at that age and choose to train, it was just really touching for me.

00:50:16:23 - 00:50:43:23

You know what I mean? And to me, I think there's nothing better than helping seeing jujitsu teach a person that they can do something that they didn't think they could do. You know, I had a student in San Francisco who a young woman who was who was visually impaired. She was, you know, just you know, she was blind, essentially.

00:50:43:23 - 00:51:08:21

Right. Like she uses a cane and all of that. And she I don't think she weighs £100. And she wanted to learn jujitsu. And so the school had asked me, you know, how do you feel about teaching like a blind woman? And I was like, This is my dream. Like, I was like, know, like, people don't know. I can't see, like, at all.

00:51:08:21 - 00:51:35:11

Like right now I can see your form and your color. I can make nothing out like I am is bad over here. So she comes to class and everybody at USF, like, really embraced her and said, you know, I remember being afraid to do the warmups with her because I was like, What if the warmups kill her? She's never done this.

00:51:35:13 - 00:51:51:11

You know what I mean? She may be like, What? I ain't got time for this ever. Yo, she never complained when we did that first warm up because I was watching her. Here come the push ups become the jujitsu push ups. You come, you know, say you come to Kimmy's. And I was waiting for her to be like, I'm out.

00:51:51:14 - 00:52:20:02

Nah, stay down. And when I would show a move, she improved me because I realized that there was a big gap between what you think you're doing and saying what you're actually doing. Yes. Yeah. There's a big gap between what you're doing and what you're saying you're doing. All right. So here I'm grabbing the wrist. Grabbing the wrist.

00:52:20:02 - 00:52:40:26

What does that mean, Grabbing the wrist with my left hand and the thumbs up, grabbing the wrist with the left hand of my thumbs down. Right. Like, you know, when you're describing a position, where is my body in proportion to their body and where am I taking them and how she improved me so much just by showing up.

00:52:40:28 - 00:53:12:13

And I remember I would be at home just like I would run through a position. How do you teach an armbar from the closed guard to a person who can't see? I do that like I had to do that. And she became really good really quickly. And so I remember one day even as as small as she was physically, one day, a girl from a very reputable school came in and she was like, Hey, I see you guys got jiu jitsu over here.

00:53:12:13 - 00:53:31:19

I've been meaning to come, but you know, school's crazy. Can I just drop in and take the class? And I was like, Sure. She was like, okay. I was like, How long you been training? She was like, a year, year and a half. I was like, All right, cool. I was like, You want to roll with her? And she was like, Yeah, yo could not pass this girl's closed guard at all.

00:53:31:22 - 00:53:50:21

You could see was trippin, you know what I'm saying? She was trippin. And you know, the girl didn't finish her from the guard, but the girl could not pass. She kept her posture broke and she kept attacking every time she would go for an armbar whatever to girl was sit up. She'd go back, you know, bring her down.

00:53:50:27 - 00:54:14:15

You know what I'm saying? She was working the sweep attempts and it was like, yo, like I started to almost cry. And then I caught myself and I said, You're only about to cry because she can't see. And by feeling that way, you're not honoring the technique that she's displaying on her own. Let her be a great champion.

00:54:14:15 - 00:54:27:24

Like, don't add anything to it. You know what I'm saying? And when that round was over, I said, How do you feel? She was out of breath. She was like, I'm okay. And I was like, All right, I'm really proud of you. You know what I'm saying? And like, this is like the beauty of of, of this path.

00:54:27:24 - 00:54:49:13

This is this is how, you know, people always think about how their teachers, like, make them better. But but I'm always impressed about how my students make me better. And so every time anybody who who's ever studied under me, they know how I end. Every class I shake their hand, I give them a fist pump and I say, thank you for improving me.

00:54:49:15 - 00:55:12:04

Thank you for improving me. And that's because you, girl. Cano said that that is the purpose of the vow. You thank your opponent for improving you because you can't armbar and throw yourself. You can't choke yourself, right? You only respond to the level of pressure put upon you that takes you up to this level of greatness. So you always thank your opponent for approving you.

00:55:12:10 - 00:55:42:03

And so I always do that. White belt to black belt. First day, last 11 minutes. I'm always going to say thank you for improving me, because that's what you do, right? Like one of my homies, Adam, he said, like, you know how like in traditional martial arts people use this, this, this like way of like bowing, right? So he saying that the thumb is bent and that the thumb symbolizes the master bowing to his students.

00:55:42:14 - 00:56:03:00

word. And he was like yeah because Risa from Wu-Tang he always does this. He was like, Yeah, it's about the Sensei, the instructor bowing before his students in gratitude, right? And the right fist being covered by the hand of peace, right? Like you're choosing peace. And I was like, What? And so I always think my, my, my, my students for improving me, my my training partners for improving me.

00:56:03:08 - 00:56:33:25

And this is what I think jiu jitsu is supposed to do. It's supposed to leave us improved, right? And if we don't allow ourselves to see our experience on the mat as more than a win loss record, like I got Tap or I tapped everybody or, you know, somewhat like none of that is relevant. You know, you improve little by little every class where you get smashed or not, and nobody will ever remember your win loss record, but they will remember your character.

00:56:33:27 - 00:56:58:02

Yeah. Wow. Yeah, That's powerful. That's awesome. Yeah, I, I really feel that story. I was going to. I didn't want to stop you midway, but I was just going to say, Isn't it wonderful to, like, feel that I feel that part where you're the teacher, but your students are teaching you, they're there helping improve you as a martial artist.

00:56:58:02 - 00:57:22:15

And as I'm not going to just say as a person, but narrow it more specifically as a communicator, right. And how you relate and have relationships with other people. So I am not trying to namedrop here, but I used to train with Hyder a amil. He would teach me for the longest time and I would go to El Nino.

00:57:22:17 - 00:57:48:10

You know, he he just recently got his contract with the UFC, you know, when is this match for that? Yeah, he killed it. The record for a UFC contenders for the Most Takedowns defended it was like eight defended 18 takedowns. Anyways, I'm off on it at my tangent like our schedules don't match up any more where I can train with him right?

00:57:48:12 - 00:58:10:09

But I've like I've improved so much in my confidence, on my feet and my striking. It's just like a whole new ballgame to me that one of my clients who I teach well, I train her out of a gym. I'm not going to say the name because, you know, it's a commercial jab and you know, they don't want outside trainers coming in and training them.

00:58:10:09 - 00:58:52:15

So I, I train. Exactly. So I train her there and she wanted to do boxing as our cardio and mind you, is the same this week. So I you know, me and Hightower couldn't find her schedule matching up. So I decided, you know what, I'm just going to continue my training. From what I've learned from him, teaching you what I know, you know, and I notice myself, like, as I have to recall, how he would teach me how to throw my jab right, how he would teach me how to throw my cross, how he would teach me, throw my hook at the record, how he's like, taught me all these different combinations and why.

00:58:52:22 - 00:59:11:05

So it's like I'm I'm, I'm switching our roles. I switching our perspective on what our on my learning process essentially by teaching through teaching her.

00:59:11:05 - 00:59:18:04

It's powerful, man. It's powerful. I mean, I can't tell you how many times when talking to my students.

00:59:18:04 - 00:59:26:03

It's really gumbi from heroes martial arts, right? It's really Gumby talking through me to them.

00:59:26:10 - 00:59:46:16

It's not really me, you know, It's. It's the echo of Gumby. It's the echo of how Gracie is the echo of Charles. Gracie, Right. And even even, like, some of my best friends, like Danny Procopio, right? It's the echo of Danny, right? Like things that they taught me. Things that they told me, things that I saw. You know what I'm saying?

00:59:46:16 - 01:00:05:18

Things that I. That I saw from BJ Penn, Right? Things that I saw from Dave Cambria back when I was a white belt. You know what I'm saying? And like that stuff still it still sticks with me. And so it's like a lot of times when I'm talking, they're hearing it from me. But but these are the echoes of of my instructors and my training partner.

01:00:05:18 - 01:00:28:03

So yeah, I told him, Yeah, yeah. Thank you. Yeah. But I think you put you're a different style, you're a different flavor and how you say it or how you communicate it to them, you know, in a different way. You know, there's definitely for sure real statements that Darren has said to me that I'm sure you got from House.

01:00:28:06 - 01:01:00:26

You know, that's like I'm just saying that verbatim. Yeah. Because I understand, you know, in that moment that's what I needed to hear. And in this moment, this is what they need to hear. Yeah. You know, but for the most part, I would say that you know how I communicate the lessons learned from all the different instructors that I've had and training partners that I've had is through my own personal communication style and how I relate to things in the world, too.

01:01:01:03 - 01:01:28:18

So, you know, there's still some flavor of. Yeah, yes, I'm saying it's going to have your seasoning on it for sure, you know, And that's how it should be, right? That's how it should be. You know, there were there these really two amazing twin boys at Oral who they're young teens, I think, you know, like, I'm going to try to put no pressure on them, but I think they can be some future Rotolo type dudes, you know what I'm saying?

01:01:28:19 - 01:01:51:22

These two brothers and they're preteens right now. And so one day one of the boys is trying to trying to take me out. And then after the match, he came up to me and he said one day, you know, I'm going to tap you out. And I said, I said, you know what? You're right, and I'm going to teach you how to do it.

01:01:51:25 - 01:02:10:10

And his face just like, drop. But what that was like, I was like, okay, I've lost my job, bro. That's my job. I said, That was going to be ten, ten, ten more years. You know what I'm saying? If you got that kind of time. But I'm here for it, you know what I'm saying? And I'll show you everything I can help you learn.

01:02:10:13 - 01:02:39:19

And so, like, you, they they they work so hard. If I tell him anything, like drink more water, they'll be like, You know what I mean? If I say move like this, like. And so that's a huge responsibility, right? That's a huge responsibility. And so like the integrity that you have to maintain within yourself and the consistency that you have to maintain inside yourself sometimes, you know, I'm 53, I'm old man.

01:02:39:19 - 01:02:58:18

I don't want to be doing air squats at 930, don't want to be doing just push ups. I don't want to do no yoga, but this lower back will lock up if I don't do that yoga and this knee might quit on you, boy, you know, I hit them air squats, right? Or we don't take that leg. So I've got to do these things right.

01:02:58:24 - 01:03:30:03

I've got to watch the footage. I've got to watch the tapes right. Because I was thinking about this when I was coming home the other day. I was like, obviously I'm 53. At some point I'm going to kick the bucket. But like in some ways, the students that I've had to share information with here in the UK and back in the Bay, you know, ten, 15, 20 years from now, they'll be my echo will be coming out of their mouth when they're teaching a technique to someone.

01:03:30:05 - 01:03:53:24

And I was actually thinking about how beautiful it's going to be to not be here, but still be teaching jiu jitsu through young men like them and others. Yeah. Yes, absolutely. I'm looking up this quote right now. It was what am I, students, fathers. He sent me this. He he sent me some new ones, too. Okay, hold on now.

01:03:54:00 - 01:04:14:11

now. Okay. This one, what he sent me was pretty funny and poignant to what you were talking about when comes to was it? here it is. This is it. When it comes to your students saying that they're going to tap you out one day. And he said to be I want to be very clear about this.

01:04:14:13 - 01:04:44:26

I'm not working out to have a healthier lifestyle. I'm working out to dominate my children in any athletic and never as possible for as long as I want them to be terrified at 28, terrified of losing to me in a footrace like that. I love your, you know, look, you like one of my favorite like student parents. You know, we're we're always chit chat.

01:04:44:27 - 01:05:09:22

You know, we're pretty tight over here at physical, but yeah, yeah, it's a good squat over there. Beautiful squat. Yeah, absolutely. Absolutely. So we you know, I got you on here talking about resilient men. We kind of diverge. You did talk, but you know, you know how the podcast podcast game is. Know how it works. Sometimes we take gadgets, we're going to get back on track.

01:05:09:27 - 01:05:41:20

Have you ever had anybody like, have any resistance or criticisms about stoicism or the projects that you have? yeah, you have to tackle those. And so there's a couple of dude things, right? Like the first is just people not knowing what Stoicism is and really not feeling it because it's an old white thing at a time when like intercultural shifts are happening and are important.

01:05:41:22 - 01:06:03:21

So people are like, Yo bro, why are you talking about all these all white dudes all the time? Like, how come you're talking about committing masters of ancient Egypt? You ain't breaking down, you know, the Creoles of West Africa. Now, the truth is, if anybody really knows an OG they know I gave those lectures back in 1992. And I'm not kidding.

01:06:03:23 - 01:06:22:27

I'm not kidding. You know, there's a book called Stolen Legacy. Anybody is free to go pick it up. It talks about the African origins of a lot of what is now Greek philosophy. Okay. And so people would be like, how come you're not talking about that? And it's really like because you didn't know me 20 years ago when I was doing it doesn't mean I didn't do it.

01:06:23:03 - 01:06:55:05

And because I don't talk about it all the time now doesn't mean I don't know it. I knew it before you knew it, probably. And I've lectured about it at a collegiate level before you were probably even in college. So that's not really the point. The thing here is if you're dealing with stoic philosophy in a time where, you know, people are struggling against white supremacy as a system, and I'm not talking about merely a police officer killing an unarmed black woman or you know what I mean?

01:06:55:07 - 01:07:17:20

You know, a bunch of officers are piling a guy in, he dies or whatever, Right? Like I'm talking about the entire system that even makes those cops see that black man as less than human whether he's committed a crime or not. The fact that they see him as less than human, the fact that they see him as a super athlete, what kind and rebel that they can't control.

01:07:17:20 - 01:07:52:02

So they got to shoot him just when he, like, reaches to undo his seatbelt. Right. Like these are the kinds of things that the system of white supremacy combats in any righteous attempt to get justice against white supremacy. I cannot have a problem with that. However, we have to be careful about doing to white society what white society has done to us, which is to to negate and deny.

01:07:52:05 - 01:08:16:02

Right. No matter what you want to say about the African origins of of of of Greek philosophy, etc., Not here to debate it, because I already know that discussions better than many of those that try to make them today like it doesn't stop what the Greeks were able to achieve. It doesn't like saying, well, you know, because hip hop comes from soul.

01:08:16:06 - 01:08:46:18

Everything rappers did is trash. What? So we're just going to deny Tupac because he sampled this dude who comes from soul. You can't do that, right? What the Stoics did what's is Seneca Epictetus. What Plato was Socrates right. What Aristotle wrote like the greatness of that is not to be denied just because white supremacy is a real thing now, right?

01:08:46:20 - 01:09:12:10

So it's like I as a black man who benefit from stoicism, I'm not going to say, well, all this Greek stuff came from Africa anyway, so whatever. No, bro, part of justice is giving credit where it's due. From the beginning period. So I don't have a problem acknowledging the African origins of, of, of philosophy in those regards and acknowledging the Stoics.

01:09:12:15 - 01:09:38:23

And I'm not going to use a time when the ideas and words of white men are kind of like out of style and not mention these guys. If they brought great truth, if they brought great justice, if they brought great wisdom, if they brought great compassion, why would I deny the value of what they bring right now? So sometimes I think in some ways people who know me, know my writing, know a lot of the things that they're like, I don't understand why he's talking about all this great stuff right now.

01:09:38:25 - 01:10:08:00

Well, it's the same reason I talked about anything, because it works. Writing about it. That means it works not for everybody, but for me and a lot of people. So I got a lot of pushback on that. I definitely I think some of the weirdest stuff that I've experienced is once I started this, this Brazilian men's group in the United Kingdom, the funniest thing that happened was, a lot of black guys from America were like, What are you doing?

01:10:08:00 - 01:10:32:00

You got this thing going on in the U.K., You're not doing it here. I was like, Cool. I started putting it together. I'm like, We got to launch it on this day. Go ahead and sign up. Crickets. Nobody signed up. Nobody signed up. So then I'm like, Yo, man, the same dudes that that deemed me looking for it were the same people that didn't show up.

01:10:33:05 - 01:10:50:28

That's right. You just have to recognize that this is where, like, I'm not even faulting them. I just think that that's how afraid of facing themselves and trying to heal so many people are. So I'm not even mad at them. One of the guys like, Yo, man, I thought you was doing the U.S. group. I said I was doing the US group and nobody signed up.

01:10:51:03 - 01:11:11:21

And he was like, Dang. I said I was going to sign up and I didn't. And I was like, It's cool. Just sign up. And then once we got ten, y'all will get a pop, you know what I mean? But the group I got, the UK is lit and so, you know, I'm still going to do one in the U.S. and it's okay that nobody signed up because I know the sign ups are coming.

01:11:11:21 - 01:11:26:28

I know that people are in pain and I know that I'm not going to stop being there for them. So it doesn't matter. And you know, the reason why I appreciate you and, you know, so any woman listening, if you know a man, even if he looks like he's cool, suggested to him, he may not even know he needs it.

01:11:27:03 - 01:11:47:05

Sometimes the strongest looking dudes are the ones that break the most suddenly and the most horrific, you know. So I appreciate for even let me talk about the RMG and I and I appreciate all the women who have suggested you should get into. I think half the dudes in the Resilient men's group in the UK were sent by wives, you know what I mean?

01:11:47:05 - 01:12:09:19

So, you know, I applaud the women who, applaud the outreach and and are part of the outreach, you know, to make to make it possible. I know, you know, just for me as a woman, I don't always find the. go ahead. Sorry. Hold on. I got it. I got it. I got a flood watch over it. I'm out.

01:12:09:21 - 01:12:40:16

The rest of the world is dying. yeah. my. So you saw the camera died there for a sec. It was okay. It still is. Things that you can't last now. I just kept talking. We'll figure it out. Well, luckily, this as this podcast also goes on Spotify, so there's probably a lot of people who just listen in any.

01:12:40:20 - 01:13:13:09

Anyway, I would back what I was. Yeah, we back. So what I, what I was trying to say is that, you know, sometimes I really try to be tactful with how I suggest these things to my friends because I also know that sometimes just the mere suggestion of things coming from my mouth set resistance, even if it was something that they would have wanted to do in the first place, you know?

01:13:13:11 - 01:13:35:13

Yeah, and that's the thing. That's the thing is this is hard, you know what I mean? It's not always it's not always easy, you know what I'm saying? But know, I'd rather have you mad with me because I suggested it from a place of love, then be mad at myself because I didn't. Then you end up harming yourself or somebody else.

01:13:35:13 - 01:13:59:02

You feel me? Yeah, Kind of like what I'm at these days. But it is hard and it is a it is a it's not an easy thing to open the door to, you know what I'm saying? Definitely. Yeah, yeah, yeah, man. It says, yeah. Well, I appreciate you out here changing. Hearts changing minds, changing lives, the work that you're doing.

01:13:59:04 - 01:14:27:17

Thank you. Yeah, I'm trying. It's important those to make my life easier, you know what I'm saying? Who make who make the conversations easier? Who lend me an ear? You know what I'm saying? It's. It's a big deal. It's a big deal. And I'm grateful. Do you have any success stories from people who've been in your group? Well, you know, the group is no, we've only been around for think like two or three months now.

01:14:27:19 - 01:15:00:02

We've only been around for like two or three months. But yes, I mean, like all of the guys in the group and it's such a such a wide group of people because we got guys as young as 18 and guys that are over 50. And it's really it's really now I find like even though like yes, I'm talking about stock philosophy and whatever, like the open conversations are the deepest ones.

01:15:00:09 - 01:15:23:11

What start talking about like, you know, I'll be like, Yo, so like, what is one aspect of your life that you know, you're letting yourself down on and why do you think that is? And then everybody kind of goes through where they're failing themselves and why they think that is. And then to watch these men support each other.

01:15:23:13 - 01:15:41:13

I mean, they're all essentially strangers, you know what I'm saying? We're all essentially strangers. And they'll be like, Hey, man, I understand what you're saying. But I think if you did this, you probably achieve it faster. Or, you know, don't be so hard on yourself because, you know, this is also possible. And it's just beautiful, like to see that stuff happen.

01:15:41:15 - 01:16:05:06

And I think that that, you know, I believe that every person, you know, has been through something that would have broken. You just don't know that story. You could have come from their childhood, could come from their teenage years. But it comes young adult could have come as a O.G. like you just don't know. You haven't had that story told to you yet.

01:16:05:08 - 01:16:28:00

And so this is one of the reasons why be chill with people because. Everybody is a survivor of something incredible. Everybody is survivor of something incredible. And when I see these guys going back forth, helping each other from the heart without judgment, it's it's just it's just magnificent. I never get tired of seeing that. You know what I mean?

01:16:28:00 - 01:16:57:04

I never get tired of seeing this. Beautiful. That's awesome. That's awesome. Any revelations for your journey doing this work, anything that you grew from just by putting this this group together, by listening their stories? Yeah. Yeah. I mean, I always knew like, I was like, okay, I got this stoic outline and know what I want to do, etc., etc. But.

01:16:57:07 - 01:17:36:05

Man, even as the guy who's the facilitator of the group, I lead by sharing my with my own vulnerability, right? With my own shortcomings, with my own pain points, with my own struggles. And I do that intentionally because, again, I'm not trying to be seen as like some type of guru who's got it all figured out. And sometimes they're they're they're their suggestions to me are groundbreaking.

01:17:36:07 - 01:18:09:01

They're Their suggestions to me are mind blowing. Their suggestions to me are supremely inspiring, you know? So, I mean, you know, it's just kind of a reflection of that whole thing. Well, let me find this quote real quick. You know, I just want to say, for the guys at home, I had this bag of plantain chips that I spilled all over the ground.

01:18:09:03 - 01:18:39:00

And my rabbit is currently acting as a vacuum cleaner for me, for my little combs that I couldn't pick up. She loves the plantation. I hope she doesn't die. Yes. What is this, Rabbits. Right now they're not. But I just. She's had them before. She intelligence and other things. But says just do this, this, this, this thing. And this was actually the first person that to teach me.

01:18:39:00 - 01:19:05:14

This was actually my fiancee and but it's true of all human beings. And this is the beauty you see in me is a reflection of you. That's Rumi. The beauty you see in me is a reflection of you. And so when I'm talking to these guys as the one that's supposed to be the facilitator, and they're reflecting all this beauty to me that I didn't expect, that I that I didn't even show up for.

01:19:05:16 - 01:19:35:03

I'm trying to show up as the helper, and then you get the help. That's just that's gold skull. Yeah. So what's next for the group? So our group meets Mondays 7 to 9 p.m.. That's I think 11 to 1 if you're on, if you're on Pacific Standard Time 1101 on Mondays. And so we are just going for it.

01:19:35:03 - 01:20:11:27

You know, we'll have our thing going on tomorrow. You know, we rotate between like deep stoic conversations and open conversations and this upcoming one is open. So I'm just looking forward to seeing what everybody's been up to. You know, it's a wide group of people, like some dudes are like attorneys for large acquisition and merger corporations and other guys are like sound bath crystal, like Masters and others are college students and others are business leaders and others are artists.

01:20:11:27 - 01:20:38:19

Like it is a and some are martial artists and it is just a ragtag group of dudes. But like, we just have the most amazing time, you know? So again, if you go to at Bishop Chronicles, you can learn how to sign up and be a part of it. And I'm working on setting up the American group like within the next few weeks, like by later than like mid-October, we should have the American RMG up and running.

01:20:38:21 - 01:21:09:04

And, you know, I'm grateful to any no one will be denied like, you know, just come through register. You know, you'll see quickly that it's a worthwhile place and space for you to here and be heard. Absolutely amazing. Adisa, any last words, anything that you didn't say, anything that we didn't talk about today that you would have loved to talk about?

01:21:09:07 - 01:21:38:06

You know what? I'm going to leave everybody with this. Do not underestimate the power of meditation and prayer do not underestimate the power of meditation and prayer. I it is a big deal. Meditation and prayer has really got me through a lot of stuff. And beyond that, I'm going to say, if you have beef with anybody or somebody's got beef with you, seek forgiveness.

01:21:38:09 - 01:22:07:04

Be willing to apologize and and be willing to listen more because life is short, man. Life is short I've lost more people in my life in the last three years than in all the years before. Sometimes, you know, situations like cancer, you know, or other diseases that were that were that were foreseeable, sometimes very sudden right. But like, life is really short.

01:22:07:04 - 01:22:28:21

And sometimes people be holding grudges because they have this illusion of time. Like, I'll let it go in a few years, man. You don't know, if you're going to be here tomorrow, you don't know if that person is going to be here tomorrow. And like I've seen it happen where people think like they can hold this grudge until X happens and then something happens and that that never that beast never gets squashed, right?

01:22:28:22 - 01:22:50:29

Only your ego lets you do that. So lean into meditation and prayer and embrace forgiveness because life is short and, you know, I don't God be for nobody, you know what I'm saying? I used to I used to be mad at people and I'm I just don't have the space to be angry anymore. I might not be happy.

01:22:50:29 - 01:23:06:11

I may have lost some respect. I may not necessarily want to be in contact with you, but that doesn't mean that I have beef with you. It doesn't. It doesn't mean that I'm happy with you. It just means that your energy and the way that we engage is not healthy. That's all that means. You know what I mean?

01:23:06:15 - 01:23:21:11

And if we can find a way for it to be healthy, I'm always that door is always open for me. You know what I mean? And I'm not always the best person my damn self, you know what I mean? So I know there's aspects of me that some people, you know, are just don't want to deal with. And that's that's that's fair too, you know what I mean?

01:23:21:11 - 01:23:43:04

Like, we're all an acquired taste, you know what I mean? To some degree, we're all an acquired taste to some degree, Right. But I don't have be for nobody. Embrace your joy, embrace your peace, Look into meditation and prayer. Do it consistently. And, you know, Google Jiu-Jitsu near me. That's what you need to do and embrace your future.

01:23:43:06 - 01:24:01:01

Awesome. Well, thank you. It is wonderful to have you on. No, thank you so much. It's such an honor. I can't wait to to to blast this out on my Facebook and tweet it out to my kinfolk. I'm very proud of you. I'm grateful for you. I don't get to tell you all the time, but you really do inspire me.

01:24:01:01 - 01:24:20:25

I'll be seeing your posts, you know what I mean? And I don't always shout you out and be like, But I'm telling you, I see you. I'm very proud of you to see you get your black belt. Like. Like my heart was just, like, trembling, man, That was a fantastic thing. You know, I think sometimes we're so busy being us.

01:24:20:25 - 01:24:41:10

Whoever we are. Everybody listening. Everybody, right? We're so busy being us. Sometimes we don't realize how amazing we are. But I would tell you, you are amazing. You are amazing. We're grateful that we crossed paths and, you know, if you ever find yourself out here, I got you. And the next time I come out there, I'll definitely look you up so we can kick it.

01:24:41:12 - 01:25:01:12

All right. Awesome. That would be great. This a mess? You love everything that you're doing. And congratulations on your new life out in the UK. Thank you so much. All right. Stay blessed and I look forward to seeing this drop. I appreciate you. All right. Take care.

01:25:01:12 - 01:25:06:07

Thank you for watching. You can watch more videos like this one by clicking these links.

